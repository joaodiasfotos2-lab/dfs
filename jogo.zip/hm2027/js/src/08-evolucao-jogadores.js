  // ============================= 08-evolucao-jogadores.js =============================
  // Evolução de jogadores / fim de época
  // Player development / end of season
  // =================================================================
  // condicoesTreino (opcional): qualidade das condições de treino do clube ATUAL do jogador.
  // Calibração 0.2.29 (auditoria à evolução): o crescimento e o declínio base passam a ser
  // multiplicados (a evolução medida era demasiado lenta — jovens de potencial 19 estagnavam em 14
  // e os veteranos quase não desciam), e o clube passa a pesar a sério:
  //  - até aos 24 anos, o treino acelera/trava o crescimento (×0,80 a ×1,30);
  //  - dos 30 em diante, treino excelente atrasa o declínio e treino fraco agrava-o;
  //  - um jovem formado no próprio clube (clubeFormadorId) cresce +7% (o valor de ter Academia);
  //  - os guarda-redes só começam a declinar com força depois dos 33.
  const DEV_GROWTH_BASE = 3.5, DEV_DECLINE_BASE = 2.5;
  const TRAINING_GROWTH_YOUNG = { "Excelentes":1.30, "Muito boas":1.15, "Boas":1.0, "Razoáveis":0.80 };
  const TRAINING_DECLINE_MULT = { "Excelentes":0.75, "Muito boas":0.90, "Boas":1.0, "Razoáveis":1.15 };
  const ACADEMY_GROWTH_BONUS = 1.07;
  const TRAINING_GROWTH_MULT = { "Excelentes":1.15, "Muito boas":1.08, "Boas":1.0, "Razoáveis":0.92 };

  // ===== Setas de evolução (pedido do utilizador, 2026-10-05) =====
  // "uma seta verde apontada para cima em cada stat que sobe, e uma encarnada apontada para baixo
  // quando um stat desce. no ovr tambem, e a ver-se no plantel. isto é so valido para a equipa do
  // utilizador. as setas devem ficar 4 semanas."
  // Em vez de instrumentar cada ponto onde um atributo pode mudar (desenvolvimento de fim de
  // época, academia mensal, lesões graves, treino...), compara-se todos os dias o valor ARREDONDADO
  // (o que o utilizador efetivamente vê) de cada atributo e do OVR com o instantâneo do dia
  // anterior — qualquer fonte de alteração fica coberta, mesmo as futuras. Só jogadores do clube
  // do utilizador (equipa A, equipa B e Academia). Sem seta quando um jogador acabou de chegar
  // (primeiro instantâneo) ou voltou depois de ter estado fora do plantel (selo evoTick diferente).
  const EVOLUCAO_SETA_DIAS = 28;
  function evolucaoSnapshot(p){
    const snap = {};
    Object.keys(p.attrs||{}).forEach(k=>{ const v=Number(p.attrs[k]); if(Number.isFinite(v)) snap[k]=Math.round(v); });
    snap.__ovr = overall(p);
    return snap;
  }
  function trackPlayerEvolution(p, tickAnterior, tickAtual, agoraMs){
    if(!p || !p.attrs) return;
    const novo = evolucaoSnapshot(p);
    const ev = p.evolucao;
    if(!ev || ev.tick !== tickAnterior || !ev.snap){
      // primeira vez que o vemos (ou voltou depois de uma ausência): só guarda o ponto de partida
      p.evolucao = { snap: novo, tick: tickAtual, attrs: {}, ovr: null };
      return;
    }
    Object.keys(novo).forEach(k=>{
      if(!Number.isFinite(ev.snap[k]) || novo[k]===ev.snap[k]) return;
      const d = novo[k] > ev.snap[k] ? 1 : -1;
      if(k==="__ovr") ev.ovr = { d, t: agoraMs };
      else { if(!ev.attrs) ev.attrs = {}; ev.attrs[k] = { d, t: agoraMs }; }
    });
    ev.snap = novo;
    ev.tick = tickAtual;
  }
  function userClubEvolutionPlayers(){
    const mine = state.teams[state.userTeamId];
    if(!mine) return [];
    const list = (mine.players||[]).slice();
    const b = mine.equipaBId && state.teams[mine.equipaBId];
    if(b) list.push(...(b.players||[]));
    if(mine.academy && mine.academy.brackets){
      Object.keys(mine.academy.brackets).forEach(br=>{ const arr = mine.academy.brackets[br] && mine.academy.brackets[br].players; if(arr) list.push(...arr); });
    }
    return list;
  }
  function trackUserSquadEvolution(){
    if(!state.userTeamId || !state.teams || !state.currentDate) return;
    const anterior = state.evolucaoTick || 0, atual = anterior + 1;
    state.evolucaoTick = atual;
    const agoraMs = new Date(state.currentDate).getTime();
    userClubEvolutionPlayers().forEach(p=>trackPlayerEvolution(p, anterior, atual, agoraMs));
  }
  // Devolve +1 (sobe) / -1 (desce) / 0 (sem seta ativa) para um atributo ("key") ou para o OVR
  // ("ovr"). Só tem efeito para jogadores do clube do utilizador (os outros nunca têm evolucao).
  function evolutionArrowDir(p, key){
    const ev = p && p.evolucao;
    if(!ev) return 0;
    const rec = key==="ovr" ? ev.ovr : (ev.attrs && ev.attrs[key]);
    if(!rec || !Number.isFinite(rec.t)) return 0;
    const agora = new Date(state.currentDate).getTime();
    return (agora - rec.t) < EVOLUCAO_SETA_DIAS*86400000 ? rec.d : 0;
  }
  function evolutionArrowHtml(p, key){
    const d = evolutionArrowDir(p, key);
    if(!d) return "";
    return d>0
      ? `<span class="evo-arrow evo-up" title="Subiu nas últimas 4 semanas" aria-label="Subiu">▲</span>`
      : `<span class="evo-arrow evo-down" title="Desceu nas últimas 4 semanas" aria-label="Desceu">▼</span>`;
  }

  // Fase 1 do roadmap Potencial/OVR: métricas puras e defensivas de desenvolvimento.
  // Não guardam estado derivado. Aceitam jogadores incompletos de saves antigos e mantêm
  // compatibilidade com chamadas já existentes no motor.
  function developmentFiniteNumber(value,fallback=0){
    const parsed=Number(value);
    return Number.isFinite(parsed)?parsed:fallback;
  }
  function playerPotentialGap(player){
    if(!player||typeof player!=="object")return 0;
    const currentOvr=developmentFiniteNumber(overall(player),0);
    const potential=developmentFiniteNumber(player.potential,currentOvr);
    return potential-currentOvr;
  }
  function playerAgeDevelopmentFactor(playerOrAge){
    const rawAge=playerOrAge&&typeof playerOrAge==="object"?playerOrAge.age:playerOrAge;
    const age=Math.max(0,developmentFiniteNumber(rawAge,0));
    if(age<=18)return 1.20;
    if(age<=21)return 1.00;
    if(age<=24)return 0.72;
    if(age<=29)return 0.34;
    return 0;
  }
  function playerDevelopmentCeiling(player){
    const gap=Math.max(0,developmentFiniteNumber(playerPotentialGap(player),0));
    return gap<=0?0:clamp(gap/4,0.18,1);
  }
  function playerSeasonUsage(player,fixtureCount,seasonValue){
    const safePlayer=player&&typeof player==="object"?player:{};
    const current=safePlayer.season&&typeof safePlayer.season==="object"?safePlayer.season:{};
    const season=seasonValue!=null?String(seasonValue):seasonLabel(state.season);
    const rows=(Array.isArray(safePlayer.historico)?safePlayer.historico:[]).filter(r=>r&&r.interno&&String(r.epoca)===season);
    const archived=rows.reduce((a,r)=>({
      jogos:a.jogos+Math.max(0,developmentFiniteNumber(r.jogos,0)),
      titular:a.titular+Math.max(0,developmentFiniteNumber(r.jogosTitular,0)),
      minutos:a.minutos+Math.max(0,developmentFiniteNumber(r.minutos,0)),
    }),{jogos:0,titular:0,minutos:0});
    const jogos=Math.max(0,developmentFiniteNumber(current.jogos,0))+archived.jogos;
    const titular=Math.min(jogos,Math.max(0,developmentFiniteNumber(current.jogosTitular,0))+archived.titular);
    const hasMinutes=current.minutos!=null||rows.some(r=>r.minutos!=null);
    const minutos=Math.max(0,developmentFiniteNumber(current.minutos,0))+archived.minutos;
    const fixtures=Math.max(1,Math.floor(developmentFiniteNumber(fixtureCount,1)));
    const gameRate=clamp(jogos/fixtures,0,1);
    // Saves antigos sem minutos conservam o comportamento anterior: jogos funcionam como proxy.
    const minuteRate=hasMinutes?clamp(minutos/(fixtures*25),0,1):gameRate;
    const startRate=clamp(titular/Math.max(1,jogos),0,1);
    const moral=developmentFiniteNumber(safePlayer.moral,70);
    const satisfacao=developmentFiniteNumber(safePlayer.satisfacao,70);
    const morale=clamp((moral+satisfacao-140)/400,-0.10,0.10);
    const loanBonus=safePlayer.emprestimo&&gameRate>=0.35?0.06:0;
    const score=clamp(gameRate*0.35+minuteRate*0.45+startRate*0.20+morale+loanBonus,0,1);
    return {jogos,titular,minutos,gameRate,minuteRate,startRate,morale,loanBonus,score};
  }
  function playerGapDevelopmentFactor(player){
    const gap=Math.max(0,playerPotentialGap(player));
    return gap<=0?0:clamp(Math.log2(gap+1)/Math.log2(9),0.15,1.35);
  }
  function baseSeasonDevelopment(player,usage){
    if(player.age<=18)return rndFloat(0.10,0.65)+usage.score*rndFloat(0.05,0.25);
    if(player.age<=21)return rndFloat(0.00,0.45)+usage.score*rndFloat(0.05,0.20);
    if(player.age<=24)return rndFloat(-0.18,0.25);
    if(player.age<=29)return rndFloat(-0.42,0.08);
    if(player.age<=32)return rndFloat(-0.8,0.4)-(1-usage.score)*0.30;
    if(player.age<=35)return rndFloat(-1.5,-0.2)-(1-usage.score)*0.45;
    return rndFloat(-2.8,-0.6)-(1-usage.score)*0.70;
  }
  function competitiveSeasonDevelopment(player,usage){
    const gapFactor=playerGapDevelopmentFactor(player);
    if(gapFactor<=0||usage.score<=0)return 0;
    return playerAgeDevelopmentFactor(player)*gapFactor*playerDevelopmentCeiling(player)*usage.score*rndFloat(1.8,3.4);
  }
  function applyDevelopmentDeltas(player,growthPoints,opts){
    const keys=Object.keys(player.attrs),stage=careerStage(player);
    const physical=new Set(player.pos==="GR"?["agilidade","resistencia","forca"]:["velocidade","aceleracao","resistencia","forca"]);
    const mental=new Set(["posicionamento","concentracao","determinacao","lideranca","criatividade"]);
    const declineMult=DEV_DECLINE_BASE*((opts&&opts.declineMult)||1)*((player.pos==="GR"&&player.age<=33)?0.6:1);
    keys.forEach(key=>{
      let weighted=growthPoints;
      if(["declinio","final"].includes(stage.id)){
        if(physical.has(key))weighted*=stage.id==="final"?1.75:1.4;
        else if(mental.has(key))weighted=Math.max(weighted*0.15,rndFloat(-0.08,0.18));
        else weighted*=0.55;
      }
      weighted*=weighted>0?DEV_GROWTH_BASE:declineMult;
      player.attrs[key]=clampAttrPrecise(player.attrs[key]+weighted/Math.max(5,keys.length*0.65)+rndFloat(-0.22,0.22));
    });
  }
  // Fase 3: aplica o teto depois de todos os deltas de atributos. Como o OVR é
  // ponderado e arredondado, limitar apenas growthPoints não garante o teto.
  // Um jogador legado já acima do potencial não é reduzido à força: o OVR de entrada
  // torna-se o seu teto pessoal e impede apenas novo crescimento positivo.
  function enforcePotentialCeiling(player,beforeAttrs,beforeOverall){
    const potential=Number(player&&player.potential);
    if(!Number.isFinite(potential)||!player||!player.attrs)return;
    const target=beforeOverall>potential?beforeOverall:potential;
    if(overall(player)<=target)return;
    const positiveKeys=Object.keys(player.attrs).filter(key=>Number.isFinite(Number(beforeAttrs[key]))&&Number(player.attrs[key])>Number(beforeAttrs[key]));
    if(!positiveKeys.length)return;
    const developed={};
    positiveKeys.forEach(key=>{developed[key]=Number(player.attrs[key]);});
    let low=0,high=1,best=0;
    for(let i=0;i<24;i++){
      const fraction=(low+high)/2;
      positiveKeys.forEach(key=>{
        const base=Number(beforeAttrs[key]);
        player.attrs[key]=clampAttrPrecise(base+(developed[key]-base)*fraction);
      });
      if(overall(player)<=target){best=fraction;low=fraction;}else high=fraction;
    }
    positiveKeys.forEach(key=>{
      const base=Number(beforeAttrs[key]);
      player.attrs[key]=clampAttrPrecise(base+(developed[key]-base)*best);
    });
    let guard=0;
    while(overall(player)>target&&guard<4000){
      const key=positiveKeys.reduce((selected,candidate)=>Number(player.attrs[candidate])-Number(beforeAttrs[candidate])>Number(player.attrs[selected])-Number(beforeAttrs[selected])?candidate:selected,positiveKeys[0]);
      const base=Number(beforeAttrs[key]);
      if(Number(player.attrs[key])<=base+0.0001)break;
      player.attrs[key]=clampAttrPrecise(Math.max(base,Number(player.attrs[key])-0.01));
      guard++;
    }
  }
  // Correção: usava sempre state.fixtures.length (getter fixo à competição do UTILIZADOR),
  // qualquer que fosse o clube do jogador a processar. As zonas Sul-A/Sul-B da 3ª Divisão têm
  // 13 equipas (em vez de 14) e por isso disputam 24 jornadas em vez de 26 — todos os jogadores
  // dessas duas zonas tinham a utilização/desempenho subestimados numa carreira fora dessas
  // zonas. jornadasCompeticao deve vir sempre do calendário da própria competição do jogador.
  function jornadasCompeticaoDoClube(teamId){
    const compId=competitionIdForTeam(teamId);
    const comp=compId?state.competitions[compId]:null;
    return (comp&&comp.fixtures&&comp.fixtures.length)?comp.fixtures.length:state.fixtures.length;
  }
  function developPlayer(p,condicoesTreino,jornadasCompeticao,teamId){
    const beforeAttrs={...p.attrs},beforeOverall=overall(p);
    const usage=playerSeasonUsage(p,jornadasCompeticao!=null?jornadasCompeticao:state.fixtures.length);
    let growthPoints=baseSeasonDevelopment(p,usage)+competitiveSeasonDevelopment(p,usage);
    if(growthPoints>0){
      if(p.age<=24)growthPoints*=TRAINING_GROWTH_YOUNG[condicoesTreino]!=null?TRAINING_GROWTH_YOUNG[condicoesTreino]:1.0;
      else if(p.age<=29)growthPoints*=TRAINING_GROWTH_MULT[condicoesTreino]!=null?TRAINING_GROWTH_MULT[condicoesTreino]:1.0;
      if(p.age<=21&&teamId&&p.clubeFormadorId===teamId)growthPoints*=ACADEMY_GROWTH_BONUS;
    }
    growthPoints+=rndFloat(-0.35,0.35);
    applyDevelopmentDeltas(p,growthPoints,{declineMult:p.age>=30?(TRAINING_DECLINE_MULT[condicoesTreino]!=null?TRAINING_DECLINE_MULT[condicoesTreino]:1.0):1.0});
    if(p.attrs.resistencia!=null){
      const ageWear=p.age<=24?rndFloat(-0.25,0.15):p.age<=29?rndFloat(-0.05,0.35):rndFloat(0.35,1+(p.age-29)*0.35);
      p.attrs.resistencia=clampAttrPrecise(p.attrs.resistencia-ageWear);
    }
    enforcePotentialCeiling(p,beforeAttrs,beforeOverall);
  }
  // Correção (auditoria): usava sortedStandings()/state.playoff sem indicar competição — os
  // 28 clubes fora da competição atualmente "vista" pelo utilizador nunca tinham a reputação
  // atualizada, e o campeão do Placard só era detetado corretamente se o utilizador estivesse
  // nessa competição no momento. Passa a percorrer as três competições explicitamente, com
  // impacto reduzido na 2ª Divisão, e as equipas B ficam de fora da reputação institucional
  // própria (competem desportivamente, mas a reputação/prestígio pertence sempre ao clube
  // principal — secção "Equipas B" da auditoria).
  function titleKey(competitionId,season=state.season){ return `${competitionId}:${seasonLabel(season)}`; }
  function playerParticipatedForTitle(player,teamId,competitionId,season=state.season){
    const rows=player.participacaoCompeticoes&&player.participacaoCompeticoes[seasonLabel(season)];
    if(!rows) return false;
    return Object.values(rows).some(r=>r&&r.clubeId===teamId&&r.competicaoId===competitionId&&(r.jogos||0)>=1);
  }
  function awardClubTitle(teamId,competitionId,label,options={}){
    const team=state.teams[teamId];if(!team)return false;
    const id=titleKey(competitionId),season=seasonLabel(state.season);
    if(!Array.isArray(team.titulosClube))team.titulosClube=[];
    if(team.titulosClube.some(t=>t.id===id))return false;
    team.titulosClube.push({id,competicao:competitionId,nome:label,epoca:season,data:isoDate(state.currentDate||new Date()),clubeId:teamId});
    (team.players||[]).forEach(p=>{
      // Compatibilidade com competições AI rápidas: se não há qualquer mapa de participação para
      // a equipa vencedora, considera o plantel inscrito; quando existe mapa, exige pelo menos 1 jogo.
      const seasonRows=p.participacaoCompeticoes&&p.participacaoCompeticoes[season];
      const hasTrackedTeam=(team.players||[]).some(x=>x.participacaoCompeticoes&&x.participacaoCompeticoes[season]&&Object.values(x.participacaoCompeticoes[season]).some(r=>r.clubeId===teamId&&r.competicaoId===competitionId));
      if(hasTrackedTeam&&!playerParticipatedForTitle(p,teamId,competitionId))return;
      if(!Array.isArray(p.titulos))p.titulos=[];
      if(!p.titulos.includes(label))p.titulos.push(label);
    });
    // Eventos Narrativos — Fase 3 ("A Lenda", 09b-eventos-narrativos.js): mais um capítulo do
    // arco sempre que o clube do utilizador conquista um título com "a lenda" ainda no plantel —
    // só depois do loop acima, para narrativeLendaTitulo já ver p.titulos actualizado.
    if(teamId===state.userTeamId && state.lendaJogadorId){
      const legenda=(team.players||[]).find(p=>p.id===state.lendaJogadorId);
      if(legenda) narrativeLendaTitulo(team,legenda,label);
    }
    return true;
  }
  function updateReputations(){
    const season=seasonLabel(state.season),changes=new Map();
    function component(teamId,key,value){if(!teamId||!state.teams[teamId]||state.teams[teamId].equipaPrincipalId)return;const row=changes.get(teamId)||{faseRegular:0,playoff:0,tituloNacional:0,tacaPortugal:0,titulo2div:0,titulo3div:0,promocao:0,descida:0,outros:0};row[key]=(row[key]||0)+value;changes.set(teamId,row);}
    // "ok-liga" (Espanha, 1ª divisão) e "serie-a1" (Itália, 1ª divisão) contam ao mesmo nível do
    // Placard — cada uma é a divisão de topo do seu próprio país, não uma divisão inferior
    // portuguesa. Sem isto, os clubes espanhóis/italianos nunca ganhariam nem perderiam reputação
    // com o desempenho na sua própria liga.
    Object.values(state.competitions).filter(c=>["placard","ok-liga","serie-a1","2div","ok-liga-plata","3div"].includes(c.divisionId)&&!c.id.includes("apuramento")).forEach(comp=>{
      const table=seasonEndTable(comp.id),n=table.length,scale=(comp.divisionId==="placard"||comp.divisionId==="ok-liga"||comp.divisionId==="serie-a1")?1:isSecondTierDivision(comp.divisionId)?.4:.2;
      table.forEach((t,idx)=>component(t.id,"faseRegular",(n/2-(idx+1))*.7*scale));
    });
    const champion=state.placardChampion||(state.playoff&&state.playoff.series&&state.playoff.series.F&&state.playoff.series.F[0]&&state.playoff.series.F[0].winner);
    if(champion){component(champion,"tituloNacional",4);component(champion,"playoff",1.5);awardClubTitle(champion,"placard",`Campeão Nacional ${season}`);}
    const okLigaChampion=state.okLigaChampion;
    if(okLigaChampion){component(okLigaChampion,"tituloNacional",4);component(okLigaChampion,"playoff",1.5);awardClubTitle(okLigaChampion,"ok-liga",`Campeão OK Liga ${season}`);}
    const serieA1Champion=state.serieA1Champion;
    if(serieA1Champion){component(serieA1Champion,"tituloNacional",4);component(serieA1Champion,"playoff",1.5);awardClubTitle(serieA1Champion,"serie-a1",`Campeão Serie A1 ${season}`);}
    const cup=state.tacaPortugal&&state.tacaPortugal.campeao;if(cup){component(cup,"tacaPortugal",3);awardClubTitle(cup,"taca-portugal",`Taça de Portugal ${season}`);}
    const second=state.secondDivisionFinal&&state.secondDivisionFinal.winner;if(second){component(second,"titulo2div",1.5);awardClubTitle(second,"2div-campeao",`Campeão da 2.ª Divisão ${season}`);}
    // OK Liga Plata: as Bases da FEP determinam que não se proclama campeão (os 1.os sobem, sem título).
    const thirdComp=state.competitions["3div-apuramento-campeao-2026-27"];
    const third=thirdComp&&thirdComp.status==="concluida"&&apuramentoStandings(thirdComp)[0]&&apuramentoStandings(thirdComp)[0].id;
    if(third){component(third,"titulo3div",1);awardClubTitle(third,"3div-campeao",`Campeão da 3.ª Divisão ${season}`);}
    const event=state.promotionEvent||{};(event.promoted||[]).forEach(id=>component(id,"promocao",2));(event.promotedFromThird||[]).forEach(id=>component(id,"promocao",1));(event.relegated||[]).forEach(id=>component(id,"descida",-2));(event.relegatedToThird||[]).forEach(id=>component(id,"descida",-1));(event.promotedEs||[]).forEach(id=>component(id,"promocao",2));(event.relegatedEs||[]).forEach(id=>component(id,"descida",-2));
    for(const [id,parts] of changes){const t=state.teams[id],before=t.reputacaoPontos!=null?t.reputacaoPontos:normalizeClubReputation(t.reputacao, t);let total=Object.values(parts).reduce((a,b)=>a+(Number(b)||0),0);if(id===champion||id===okLigaChampion||id===serieA1Champion)total=Math.max(1,total);if(id===cup)total=Math.max(.5,total);total=clamp(total,-5,7);const after=clamp(before+total,5,99);t.reputacaoPontos=after;t.reputacao=reputationFromPoints(after);
      // Correção (bug real, reportado pelo utilizador): o objetivo desportivo da direção ficava
      // congelado no valor do início de carreira, mesmo com a reputação do clube a mudar todas as
      // épocas — ver refreshSponsorObjetivo, em 04-financas.js.
      refreshSponsorObjetivo(t);
      if(!Array.isArray(t.historicoReputacao))t.historicoReputacao=[];const row={epoca:season,reputacaoInicial:before,...parts,variacaoTotal:after-before,reputacaoFinal:after};const idx=t.historicoReputacao.findIndex(x=>x.epoca===season);if(idx>=0)t.historicoReputacao[idx]=row;else t.historicoReputacao.push(row);}
  }

  function internalTransferPairForUser(){
    const current=myTeam(); if(!current) return null;
    const aId=current.equipaPrincipalId || current.id;
    const a=state.teams[aId], b=state.teams[(a&&a.equipaBId)||current.equipaBId];
    return a&&b ? {a,b} : null;
  }
  function canRemoveForInternalTransfer(team,player){
    // Pedido do utilizador (2026-10-03: "Devo poder trocar entre equipas A e B no dia do jogo"):
    // o bloqueio cobria também o dia de jogo (desde que state.pendingFixture ficava definido, logo
    // ao chegar a jornada, até ao fim da partida) — impossibilitava reforçar a equipa A a partir da
    // B (ou vice-versa) precisamente quando a falta de jogadores disponíveis mais se nota. Passa a
    // bloquear só a partida em si (state.match, jogo já a decorrer/simulado) — a preparação (ver a
    // convocatória, escolher o 5 inicial) já não impede o movimento interno.
    // Correção (2026-10-12, "este erro continua"): state.match só voltava a null no fim de uma jornada
    // da liga (maybeAdvanceRound) — depois de um jogo de taça, playoff, supertaça, Elite Cup ou
    // amigável acabado, ficava preso ao jogo já terminado e o bloqueio nunca mais saía. Só um jogo
    // ainda por acabar (a decorrer, pausado ou à espera do "Iniciar Jogo") impede o movimento.
    if(state.match && !state.match.finished) return {ok:false,reason:"Não é possível mover jogadores durante a realização de um jogo."};
    const remaining=team.players.filter(p=>p.id!==player.id);
    if(player.pos==="GR" && !remaining.some(p=>p.pos==="GR")) return {ok:false,reason:"A equipa de origem tem de manter pelo menos 1 guarda-redes."};
    if(player.pos!=="GR" && remaining.filter(p=>p.pos==="J").length<5) return {ok:false,reason:"A equipa de origem tem de manter pelo menos 5 jogadores de campo."};
    return {ok:true};
  }
  function archiveInternalStint(player,team){
    if(!player.season || !(player.season.jogos||0)) return;
    if(!Array.isArray(player.historico)) player.historico=[];
    player.historico.push({epoca:seasonLabel(state.season),clube:team.name,jogos:player.season.jogos||0,jogosTitular:player.season.jogosTitular||0,jogosSuplente:player.season.jogosSuplente||0,minutos:player.season.minutos||0,golos:player.season.golos||0,assistencias:player.season.assistencias||0,golosSofridos:player.season.golosSofridos||0,interno:true});
    // 2026-10-16: o troço também conta para a carreira — antes era zerado sem nunca entrar em career.
    if(!player.career) player.career=createEmptyStats("career");
    ["golos","assistencias","jogos","amarelos","azuis","vermelhos","mvp","golosSofridos","penaltisMarcados","penaltisDefendidos","livresDiretosMarcados","livresDiretosDefendidos"]
      .forEach(k=>{ player.career[k]=(player.career[k]||0)+(player.season[k]||0); });
    Object.keys(player.season).forEach(k=>{ if(typeof player.season[k]==="number") player.season[k]=0; });
    player.season.notas=[];
  }
  function internalTransferImpact(player,direction){
    if(direction==="paraB"){
      const experience=clamp((player.age-21)*.55+(player.career.jogos||0)*.035+(player.reputacaoJogador||0)*.12,4,20);
      return {moral:-Math.round(experience),satisfacao:-Math.round(experience*1.15)};
    }
    const form=player.season&&player.season.notas&&player.season.notas.length?avg(player.season.notas):6;
    const merit=clamp(6+(player.season.jogos||0)*.35+(form-6)*2.2,6,18);
    return {moral:Math.round(merit),satisfacao:Math.round(merit*.9)};
  }
  function transferPlayerBetweenAandB(playerId,originId,targetId){
    const origin=state.teams[originId],target=state.teams[targetId],player=origin&&origin.players.find(p=>p.id===playerId);
    if(!origin||!target||!player) return {ok:false,reason:"Jogador ou equipa não encontrados."};
    if(player.emprestimo) return {ok:false,reason:"Um jogador emprestado não pode ser movido para a equipa B do clube de destino."};
    const pair=internalTransferPairForUser();
    if(!pair || ![pair.a.id,pair.b.id].includes(originId) || ![pair.a.id,pair.b.id].includes(targetId)) return {ok:false,reason:"Movimento interno inválido."};
    const check=canRemoveForInternalTransfer(origin,player); if(!check.ok) return check;
    archiveInternalStint(player,origin);
    origin.players=origin.players.filter(p=>p.id!==player.id); target.players.push(player);
    // Se este jogador estava emprestado só para o jogo de hoje (tryBorrowFromSibling,
    // 09-fluxo-epoca.js), este movimento manual torna-o permanente — já não há nada a "devolver"
    // depois da partida.
    delete player.__loanedForMatchFrom;
    player.titular=false; const direction=target.id===pair.b.id?"paraB":"paraA",impact=internalTransferImpact(player,direction);
    player.moral=clamp((player.moral||60)+impact.moral,0,100); player.satisfacao=clamp((player.satisfacao||60)+impact.satisfacao,0,100);
    state.internalTransferHistory.unshift({date:new Date(state.currentDate).toISOString(),player:player.name,from:origin.name,to:target.name,direction,moral:impact.moral,satisfacao:impact.satisfacao});
    // Correção (pedido do utilizador, 2026-10-03: "não podem aparecer notícias de despromoções ou
    // promoções de jogadores entre equipas A e B") — este movimento continua registado em
    // state.internalTransferHistory (consultável na Ficha do Jogador/Mercado Interno), mas deixa
    // de gerar uma notícia na caixa de entrada; era ruído sempre que o próprio utilizador ou a IA
    // reorganizavam o plantel entre a equipa A e a B.
    return {ok:true};
  }

  function teamNamesHtml(ids){ return (ids||[]).map(id=>state.teams[id]?teamLinkHtml(id):escapeHtml(id)).join("<br>") || "—"; }
  function showSeasonSummary(summary){
    const modal=document.getElementById("seasonSummaryModal"),body=document.getElementById("seasonSummaryBody"); if(!modal||!body||!summary)return;
    const userEs=!!state.teams[state.userTeamId]&&teamCountry(state.teams[state.userTeamId])==="es"&&Array.isArray(summary.promotedEs)&&summary.promotedEs.length>0;
    body.innerHTML=`<div class="season-summary-grid">
      <div class="season-summary-card"><h4>Campeão nacional</h4><b>${summary.champion&&state.teams[summary.champion]?teamLinkHtml(summary.champion):"—"}</b></div>
      <div class="season-summary-card"><h4>Melhor marcador</h4><b>${escapeHtml(summary.topScorerName||"—")}</b><div>${summary.topScorerGoals||0} golos</div></div>
      ${userEs?`<div class="season-summary-card"><h4>Promovidos à OK Liga</h4><div>${teamNamesHtml(summary.promotedEs)}</div></div>
      <div class="season-summary-card"><h4>Despromovidos à OK Liga Plata</h4><div>${teamNamesHtml(summary.relegatedEs)}</div></div>`:`<div class="season-summary-card"><h4>Promovidos ao Placard</h4><div>${teamNamesHtml(summary.promoted)}</div></div>
      <div class="season-summary-card"><h4>Despromovidos à 2.ª Divisão</h4><div>${teamNamesHtml(summary.relegated)}</div></div>`}
      ${(!userEs&&summary.promotedFromThird)?`<div class="season-summary-card"><h4>Promovidos da 3.ª Divisão</h4><div>${teamNamesHtml(summary.promotedFromThird)}</div></div>`:""}
      ${(summary.bRule&&summary.bRule.length)?`<div class="season-summary-card"><h4>Regra A/B — equipas B afetadas</h4><div>${summary.bRule.map(e=>e.tipo==="regressa"?`${teamLinkHtml(e.b)} regressa na 3.ª Divisão (a ${teamLinkHtml(e.a)} subiu da 3.ª)`:e.tipo==="desce"?`${teamLinkHtml(e.b)} desce à 3.ª Divisão (a ${teamLinkHtml(e.a)} desceu à 2.ª)`:`${escapeHtml(state.teams[e.b]?state.teams[e.b].name:e.b)} cessa a participação (a ${teamLinkHtml(e.a)} desceu à 3.ª)`).join("<br>")}</div></div>`:""}
      ${(!userEs&&summary.relegatedToThird)?`<div class="season-summary-card"><h4>Despromovidos à 3.ª Divisão</h4><div>${teamNamesHtml(summary.relegatedToThird)}</div></div>`:""}
    </div>`;
    modal.classList.remove("hidden");
  }
  const seasonSummaryCloseBtn=document.getElementById("seasonSummaryCloseBtn"); if(seasonSummaryCloseBtn) seasonSummaryCloseBtn.addEventListener("click",()=>document.getElementById("seasonSummaryModal").classList.add("hidden"));

  // Fase 15: ecrã de defeso — resumo consolidado de entradas, saídas, renovações, dívida e
  // orçamento da nova época, mostrado antes de o utilizador avançar efetivamente de época.
  function renderDefesoModal(){
    const modal=document.getElementById("defesoModal"), body=document.getElementById("defesoModalBody");
    if(!modal||!body) return;
    { const _gm=document.getElementById("defesoGoToMarketBtn"); if(_gm) _gm.style.display=""; const _cb=document.getElementById("defesoContinueBtn"); if(_cb) _cb.classList.remove("ps-go-btn"); const _tt=document.getElementById("defesoModalTitle"); if(_tt) _tt.style.display=""; const _bx=modal.querySelector(".modal-box"); if(_bx){ _bx.style.maxWidth="760px"; _bx.classList.remove("ps-box"); } const _sm=document.getElementById("psSummary"); if(_sm) _sm.remove(); }
    // Correção (pedido do utilizador, 2026-09-14): idem renderPreSeasonModal (05-ui-navegacao.js)
    // — o título deixa de dizer "Defeso", passa a "Fim de Época" (já era o texto por omissão no
    // HTML, definido aqui explicitamente para nunca ficar preso ao título de pré-época anterior).
    const titleEl = document.getElementById("defesoModalTitle"); if(titleEl) titleEl.textContent = "Fim de Época";
    const team=myTeam();
    const stats=state.lastDefesoStats||{renovados:0,dispensados:0,preContratosAtivados:0,reforcosLivres:0};
    const summary=state.pendingSeasonSummary||{};
    let userGoalsHtml="";
    if(team){
      initClubFinance(team);
      const evalResult=(team.avaliacaoDirecao&&team.avaliacaoDirecao[0]) || evaluateDirectionGoals(team);
      userGoalsHtml=`<div class="season-summary-card"><h4>Avaliação da direção — ${teamLinkHtml(team.id)}</h4>
        <b>${evalResult.passed}/${evalResult.total} objetivos cumpridos</b>
        <ul style="margin:6px 0 0;padding-left:18px;font-size:12px;">
          ${evalResult.goals.map(g=>`<li style="color:${g.ok?'#16834b':'var(--vermelho)'};">${escapeHtml(g.label)}: ${g.ok?'cumprido':'por cumprir'}</li>`).join("")}
        </ul>
      </div>
      <div class="season-summary-card"><h4>Finanças do clube</h4>
        Saldo: ${fmtMoney(team.financeiro.saldo)}<br>
        Dívida: ${fmtMoney(team.financeiro.divida||0)}<br>
        Massa salarial: ${Math.round(wageToBudgetRatio(team)*100)}% do limite
      </div>`;
    }
    body.innerHTML = `<div class="season-summary-grid">
      <div class="season-summary-card"><h4>Campeão nacional</h4><b>${summary.champion&&state.teams[summary.champion]?teamLinkHtml(summary.champion):"—"}</b></div>
      <div class="season-summary-card"><h4>Melhor marcador</h4><b>${escapeHtml(summary.topScorerName||"—")}</b><div>${summary.topScorerGoals||0} golos</div></div>
      <div class="season-summary-card"><h4>Mercado de verão</h4>
        Renovações: ${stats.renovados}<br>
        Contratos terminados / dispensas: ${stats.dispensados}<br>
        Pré-contratos ativados: ${stats.preContratosAtivados}<br>
        Reforços do mercado de livres: ${stats.reforcosLivres}<br>
        Jogadores livres disponíveis: ${(state.freeAgents||[]).length}
      </div>
      ${userGoalsHtml}
      <div class="season-summary-card"><h4>Promovidos ao Placard</h4><div>${teamNamesHtml(summary.promoted)}</div></div>
      <div class="season-summary-card"><h4>Despromovidos à 2.ª Divisão</h4><div>${teamNamesHtml(summary.relegated)}</div></div>
    </div>
    <p class="helptext" style="margin-top:10px;">Os plantéis e mínimos de inscrição de todos os clubes já foram validados. Podes rever a Central de Contratos e o Mercado antes de avançar.</p>`;
    const btn=document.getElementById("defesoContinueBtn"); if(btn) btn.textContent="Avançar para a nova época";
    modal.classList.remove("hidden");
  }
  const defesoContinueBtn=document.getElementById("defesoContinueBtn");
  if(defesoContinueBtn) defesoContinueBtn.addEventListener("click", () => {
    // Proteção contra dupla ativação (encontrada nos testes gerais, 2026-10-05): sem este guarda,
    // um segundo clique/ativação depois de o ecrã já ter fechado (inDefeso e isPreSeasonDefeso
    // ambos a false) caía no ramo "else" e chamava finalizeNewSeason() em plena época — avançava a
    // época (season+1) sem fechar a anterior, sem resumo e com a Elite Cup sem qualificação.
    if(!state.inDefeso && !state.isPreSeasonDefeso) return;
    // Ampulheta (mesmo cursor do "Continuar") enquanto a época/pré-época é processada.
    const _go = () => { if(state.isPreSeasonDefeso) finalizePreSeasonDefeso(); else finalizeNewSeason(); };
    if(typeof window.hm2027Pensar==="function") window.hm2027Pensar(_go); else _go();
  });

  // Correção (auditoria, bug crítico #2): rede de segurança de TAMANHO de plantel para as
  // equipas B (para além do caso já protegido do guarda-redes) — nunca recorre ao mercado
  // externo, só a recursos do próprio clube, pela ordem que a auditoria recomenda: primeiro um
  // jogador pouco utilizado da equipa A (despromoção interna), só depois um jovem de emergência
  // gerado fora do calendário normal da formação (nunca jogadores livres, essa é a regra da
  // equipa B que já ficou definida).
  const B_TEAM_MIN_GR = STRUCTURAL_MIN_GOALKEEPERS, B_TEAM_MIN_J = 5;
  // Idade máxima para um "jovem de emergência" (gerado mais abaixo, via generateAcademyGoalkeeper/
  // Outfield no escalão sub17) continuar a contar como reforço de formação da equipa B. Correção
  // (pedido do utilizador, 2026-10-03: "as equipas B com idades inventadas não podem ter jogadores
  // com mais de 20 anos", ajustado no mesmo dia para 22) — sem nenhuma purga, estes jogadores
  // sintéticos iam envelhecendo
  // normalmente (refreshPlayerAge, 01-nucleo.js) e acumulando-se época após época em clubes de IA
  // com carências persistentes, até a equipa B ficar cheia de "jovens" já na casa dos 25-30 anos —
  // o oposto do que esta rede de segurança deveria simular. Os marcados com
  // __bTeamEmergencyFiller (só estes — nunca os promovidos normalmente pela Academia, que devem
  // continuar a envelhecer como qualquer jogador real) deixam de contar como "jovem" assim que
  // ultrapassam este limite, antes de se avaliar se a equipa B ainda precisa de reforço.
  const B_TEAM_EMERGENCY_FILLER_MAX_AGE = 22;
  // Correção (pedido do utilizador, 2026-10-03: "não podem simplesmente desaparecer. Se passam dos
  // 20 anos e não servem para a equipa A, ou são vendidos ou dispensados") — a primeira versão
  // desta purga arquivava-os em state.inactivePlayers, um registo puramente interno sem NENHUMA
  // visibilidade na interface (ao contrário de state.freeAgents, que aparece na pesquisa de
  // jogadores como "Agente livre" e pode ser recontratado por qualquer clube) — na prática, para
  // quem joga, era como se o jogador se tivesse esfumado. Passa a decidir-se caso a caso: se já tem
  // nível para a equipa A, sobe à equipa A como qualquer promoção normal; caso contrário, só quando
  // já passou do limite de idade, é dispensado para o mercado de agentes livres — nunca arquivado
  // sem rasto.
  function promoteBTeamFillerToA(player, bTeam, parent){
    bTeam.players = bTeam.players.filter(p=>p.id!==player.id);
    delete player.__bTeamEmergencyFiller;
    player.titular = false;
    player.__promotedFromBSeason = state.season; // mesma proteção de oscilação de tryBTeam
    parent.players.push(player);
  }
  function releaseAgedBTeamFillerToFreeAgency(player, bTeam){
    bTeam.players = bTeam.players.filter(p=>p.id!==player.id);
    delete player.__bTeamEmergencyFiller;
    rememberFreeAgentOrigin(player, bTeam);
    player.titular = false; player.__manualResolutionSeason = state.season;
    player.contrato = null; player.preContrato = null;
    state.freeAgents = (state.freeAgents||[]).concat(player);
  }
  function ensureBTeamMinimums(onlyTeamId){
    Object.values(state.teams).filter(t=>t.equipaPrincipalId && !t.equipaExtinta && (!onlyTeamId || t.id===onlyTeamId)).forEach(bTeam=>{
      const parent = state.teams[bTeam.equipaPrincipalId];
      if(!parent) return;
      // Correção (pedido do utilizador, 2026-10-04: "pode sempre subir à A em qualquer altura") —
      // antes, um jovem de emergência só era reavaliado para subir à equipa A quando ultrapassava
      // B_TEAM_EMERGENCY_FILLER_MAX_AGE — um jogador já com nível para a A ficava preso na B até lá,
      // mesmo sendo claramente melhor do que o pior titular do clube-mãe. Agora TODOS os jogadores
      // __bTeamEmergencyFiller (qualquer idade) são reavaliados de cada vez que esta função corre
      // (uma vez por época): quem já supera o pior jogador do clube-mãe na mesma posição sobe de
      // imediato; só quem ainda não tem nível E já passou do limite de idade é dispensado.
      bTeam.players.filter(p=>p.__bTeamEmergencyFiller).slice().forEach(p=>{
        const rivaisNaPosicao = parent.players.filter(x=>x.pos===p.pos);
        const piorDaEquipaA = rivaisNaPosicao.length ? Math.min(...rivaisNaPosicao.map(overall)) : -Infinity;
        if(overall(p) > piorDaEquipaA){
          promoteBTeamFillerToA(p, bTeam, parent);
        } else if((p.age||0) > B_TEAM_EMERGENCY_FILLER_MAX_AGE){
          releaseAgedBTeamFillerToFreeAgency(p, bTeam);
        }
      });
      let guard=0;
      while((bTeam.players.filter(p=>p.pos==="GR").length<B_TEAM_MIN_GR || bTeam.players.filter(p=>p.pos==="J").length<B_TEAM_MIN_J) && guard<8){
        const needGR = bTeam.players.filter(p=>p.pos==="GR").length<B_TEAM_MIN_GR;
        const need = needGR ? "GR" : "J";
        // Correção (bug real, encontrado num teste alargado de 5 épocas): usava [] para
        // representar "sem candidato" quando o clube-mãe é o do utilizador — mas um array vazio
        // é um valor "truthy" em JS, por isso o "if(candidateFromA)" logo a seguir considerava
        // sempre que HAVIA candidato. Empurrava-se então esse array vazio para bTeam.players
        // como se fosse um jogador (com .id/.name/.pos/.attrs todos undefined), e
        // "candidateFromA.titular=false" limitava-se a pendurar essa propriedade no próprio
        // array. Este "jogador" fantasma acabava por acumular estatísticas de época/carreira e
        // dados de jogo (season, career, condição, moral, satisfação, __fitness, etc.) ao ser
        // usado nos jogos simulados da equipa B — e, no fecho da época seguinte, overall() do
        // motor de jogo tentava ler ".attrs" de um objeto que nunca teve, rebentando com "Cannot
        // read properties of undefined (reading 'habilidade')". Essa exceção não tratada
        // interrompia todo o closeCompletedSeasonPlayerStats() a meio — saltando reformas,
        // subida/descida de divisão e a preparação da Elite Cup nessa transição de época (só se
        // recuperava numa tentativa seguinte, ao clicar de novo). Corrigido para null — "sem
        // candidato" deixa de ser confundido com "há candidato", e o código cai corretamente no
        // ramo de geração de um jovem de emergência, como já era a intenção.
        // Correção (pedido do utilizador, 2026-10-03: "estão jogadores a ser despromovidos e
        // promovidos logo a seguir em equipas da IA e que não fazem sentido") — esta despromoção
        // corria sem olhar a quem tinha acabado de SUBIR da equipa B para a A momentos antes, na
        // mesma transição de época (tryBTeam, 04-financas.js, dentro de processAiToAiMarket, que
        // corre sempre antes de ensureBTeamMinimums). Um jovem promovido por carência fica, por
        // definição, não-titular e com 0 jogos na época nova — exactamente o perfil que este
        // candidato procura — por isso podia ser escolhido para descer outra vez de imediato,
        // desfazendo a subida que acabara de acontecer. __promotedFromBSeason (marcado em
        // tryBTeam) protege-o de ser reenviado para a B na mesma época em que subiu.
        const candidateFromA = isUserControlledTeam(parent) ? null : parent.players.filter(p=>p.pos===need && !p.titular && p.__promotedFromBSeason!==state.season && (seasonStatsForDecision(p).jogos||0)<=2 && canReleasePlayerFromTeam(parent,p).ok)
          .sort((a,b)=>overall(a)-overall(b))[0];
        if(candidateFromA){
          parent.players = parent.players.filter(p=>p.id!==candidateFromA.id);
          bTeam.players.push(candidateFromA); candidateFromA.titular=false;
          // Correção (pedido do utilizador, 2026-10-03: "não podem aparecer notícias de
          // despromoções ou promoções de jogadores entre equipas A e B") — este movimento
          // automático de IA deixa de gerar notícia; o jogador continua a mudar de equipa
          // normalmente, só deixa de encher a caixa de entrada.
          guard++; continue;
        }
        const id = `${bTeam.id}-emerg-${state.season}-${guard}-${uid()}`;
        const paisPai=teamCountry(parent);
        const name = randomNameForCountry(paisPai);
        const num = findFreeNumber(bTeam);
        // Academia e Juvenis (Fase 5, 2026-09-22): substitui generateYouthGoalkeeper/
        // generateYouthOutfield (removidas de 01-nucleo.js nesta fase) pelos equivalentes da
        // Academia, lendo parent.academy?.level em vez de parent.qualidadeFormacao (já removido).
        // Usa o escalão "sub17" (16-17 anos, sem desvio de atributo — ACADEMY_BRACKET_BASE_OFFSET
        // .sub17===0) por ser o que mais se aproxima da idade 15-17/16-17 que o gerador antigo
        // produzia para este mesmo fim de rede de segurança síncrona da equipa B.
        // Nível de referência (pedido do utilizador, 2026-10-05: equipa B nunca pior do que a formação): o jovem de
        // emergência nasce ao nível médio da equipa B (o desvio relativo do Sub-17 é -2,5, compensado aqui).
        const fillerRef = academyReferenceLevel(parent) - ACADEMY_REL_OFFSET.sub17;
        const player = needGR ? generateAcademyGoalkeeper(id,num,name,parent.academy?.level||3,paisPai,"sub17",fillerRef) : generateAcademyOutfield(id,num,name,parent.academy?.level||3,paisPai,"sub17",fillerRef);
        // Este jogador nunca passa pelos escalões da academia (vai directo para o plantel da
        // equipa B) — remove academyBracket para não confundir código futuro (Fase 6, interface)
        // que use esse campo como sinal de "ainda está na academia" (mesmo padrão de limpeza já
        // usado em runAcademySub19ExitPass, ao promover).
        delete player.academyBracket;
        // Marca este jogador como "jovem de emergência" desta rede de segurança (distinto de
        // __academyGenerated, que também é verdadeiro para promoções normais da Academia que
        // devem continuar a envelhecer livremente) — usado só para a purga de idade no topo desta
        // função (B_TEAM_EMERGENCY_FILLER_MAX_AGE), nunca para qualquer outro efeito de jogo.
        player.__bTeamEmergencyFiller = true;
        // Correcção (2026-09-23): os geradores da Academia forçam salarioMensal a 0 (atletas da
        // formação não são remunerados) — mas este jogador não fica na Academia, entra logo no
        // plantel real da equipa B, por isso precisa de um salário normal como qualquer jogador
        // profissional, recalculado pela mesma fórmula de generateContract.
        player.contrato.salarioMensal = generateContract(overall(player), player.age, { potential: player.potential }).salarioMensal;
        bTeam.players.push(player);
        guard++;
      }
    });
  }

  function endOfSeason(){
    if(!globalSeasonReadyToClose()) return;
    beginDefeso();
  }

  // Fase 15: fluxo de defeso próprio — resolve tudo o que compete ao fim da época (promoção/
  // descida, prémios, reputações, contratos, mercado de verão, avaliação da direção) e mostra
  // um resumo consolidado antes de o utilizador avançar efetivamente para a nova época, em vez
  // de saltar logo para lá.
  // Fecha a época antes de qualquer movimento do defeso, preservando o clube correto.
  // Rede de segurança defensiva: remove, antes de processar o fecho de época, (a) qualquer
  // entrada de team.players sem identidade válida (sem id/pos/attrs) e (b) qualquer jogador
  // provisório (Henrique Dias/emergência) que tenha ficado esquecido no plantel depois de um
  // jogo. Nenhum jogador legítimo fica alguma vez sem id/pos/attrs — só um objeto "fantasma" (ex.:
  // o bug real do array vazio empurrado por ensureBTeamMinimums, já corrigido) poderia chegar
  // aqui assim; sem esta limpeza, overall()/computePlayerReputation() rebentava a meio do forEach
  // (Cannot read properties of undefined, reading 'habilidade'), interrompendo TODO o fecho de
  // época a meio — reformas, subida/descida de divisão e Elite Cup ficavam por processar até a
  // uma tentativa seguinte conseguir "saltar" o jogador partido. E, por definição
  // (ver makeHenriqueDias, 09-fluxo-epoca.js), um jogador provisório "nunca fica no plantel,
  // carreira, histórico ou save" — encontrar um aqui (real, confirmado num teste alargado de 5
  // épocas: "Henrique Dias" persistiu no plantel do clube do utilizador até ao fim da época)
  // significa que alguma chamada a ensureMinimumSquad() não teve o removeProvisionalPlayers()
  // correspondente depois do jogo; mantém-se por segurança mesmo que essa chamada específica
  // venha a ser encontrada e corrigida. Mantém-se também como proteção para saves antigos já
  // corrompidos por qualquer uma destas duas causas.
  function purgeGhostPlayers(){
    let removed=0;
    Object.values(state.teams).forEach(team=>{
      const before=team.players.length;
      team.players=team.players.filter(p=>p && typeof p==="object" && p.id!=null && p.pos!=null && p.attrs && typeof p.attrs==="object" && !p.__provisional);
      removed += before - team.players.length;
    });
    if(removed) console.warn(`[HM2027] ${removed} entrada(s) de plantel sem identidade válida ou provisórias esquecidas removida(s) antes do fecho de época.`);
    return removed;
  }
  function closeCompletedSeasonPlayerStats(){
    purgeGhostPlayers();
    Object.values(state.teams).forEach(team=>{
      // Correção (bug reportado pelo utilizador, 2026-09-27: "as seleções não são clubes") — uma
      // equipa virtual de Seleção Nacional partilha os MESMOS objetos de jogador com o respetivo
      // clube real (nunca cópias, ver pickNationalSquad/makeVirtualSelecaoTeam, 07h-selecoes.js) e
      // já existe em state.teams quando esta função corre (prepareSelecoesEdicaoForNewSeason é
      // chamada logo no início de beginDefeso, antes desta). Sem esta exclusão, cada jogador
      // convocado tinha o seu fecho de época de CLUBE processado uma segunda vez sob o "clube"
      // virtual da seleção — jornadasCompeticaoDoClube(team.id) não encontra nenhuma competição
      // real para esse id, o que contaminava a mistura de reputacaoJogador (linha abaixo) e
      // aplicava um segundo developPlayer() espúrio, além de criar uma entrada fantasma no
      // histórico de época do jogador com o nome do país como "clube".
      if(team.selecaoNacional) return;
      const jornadasCompeticao=jornadasCompeticaoDoClube(team.id);
      team.players.forEach(player=>{
        if(!Array.isArray(player.historico)) player.historico=[];
        const row={
          epoca:seasonLabel(state.season), clube:team.name,
          jogos:player.season.jogos||0, jogosTitular:player.season.jogosTitular||0,
          jogosSuplente:player.season.jogosSuplente||0, golos:player.season.golos||0,
          assistencias:player.season.assistencias||0, golosSofridos:player.season.golosSofridos||0,
          emprestimo:!!player.emprestimo,
          movimento: player.movimentoEntrada && player.movimentoEntrada.epoca===state.season && player.movimentoEntrada.clubeId===team.id
            ? {tipo:player.movimentoEntrada.tipo,valor:player.movimentoEntrada.valor||0} : null
        };
        const idx=player.historico.findIndex(h=>!h.interno&&String(h.epoca)===String(row.epoca)&&String(h.clube)===String(row.clube)); // não sobrepor uma linha de troço interno A↔B
        const archiveKey=`${row.epoca}:${team.id}`;
        if(idx>=0) player.historico[idx]=row; else player.historico.push(row);
        if(!Array.isArray(player.careerArchivesApplied))player.careerArchivesApplied=[];
        if(player.careerArchivesApplied.includes(archiveKey)){player.season=createEmptyStats("season");return;}
        player.careerArchivesApplied.push(archiveKey);player.careerArchivesApplied=player.careerArchivesApplied.slice(-40);
        player.career.golos+=(player.season.golos||0);
        player.career.assistencias+=(player.season.assistencias||0);
        player.career.jogos+=(player.season.jogos||0);
        player.career.amarelos=(player.career.amarelos||0)+(player.season.amarelos||0);
        player.career.azuis=(player.career.azuis||0)+(player.season.azuis||0);
        player.career.vermelhos=(player.career.vermelhos||0)+(player.season.vermelhos||0);
        player.career.mvp=(player.career.mvp||0)+(player.season.mvp||0);
        player.career.golosSofridos=(player.career.golosSofridos||0)+(player.season.golosSofridos||0);
        player.career.penaltisMarcados=(player.career.penaltisMarcados||0)+(player.season.penaltisMarcados||0);
        player.career.penaltisDefendidos=(player.career.penaltisDefendidos||0)+(player.season.penaltisDefendidos||0);
        player.career.livresDiretosMarcados=(player.career.livresDiretosMarcados||0)+(player.season.livresDiretosMarcados||0);
        player.career.livresDiretosDefendidos=(player.career.livresDiretosDefendidos||0)+(player.season.livresDiretosDefendidos||0);
        const baseRep=computePlayerReputation(player),avgRating=player.season.notas&&player.season.notas.length?avg(player.season.notas):6;
        const performance=clamp((player.season.jogos||0)/Math.max(1,jornadasCompeticao)*8+(player.season.golos||0)*.35+(player.season.assistencias||0)*.25+(player.season.mvp||0)*.5+(avgRating-6)*3,0,18);
        player.reputacaoJogador=clamp(Math.round(((player.reputacaoJogador||baseRep)*.55+baseRep*.35+performance*.10)*10)/10,0,100);
        developPlayer(player,team.condicoesTreino,jornadasCompeticao,team.id);
        player.__seasonFechada=player.season; player.__seasonFechadaEpoca=state.season; // ver seasonStatsForDecision
        player.season=createEmptyStats("season");
        player.condicao=100;
        delete player.__manualResolutionSeason;
        if(player.movimentoEntrada && player.movimentoEntrada.epoca===state.season) delete player.movimentoEntrada;
      });
    });
  }

  // Correção v33: estabelece a estrutura estatística como invariável de domínio.
  // Preenche apenas campos ausentes e nunca substitui estatísticas válidas existentes.
  function cloneEmptyStatValue(value){
    if(Array.isArray(value)) return [];
    if(value&&typeof value==="object") return JSON.parse(JSON.stringify(value));
    return value;
  }
  function ensurePlayerStatsStructure(player){
    if(!player||typeof player!=="object") return false;
    const emptySeason=createEmptyStats("season"),emptyCareer=createEmptyStats("career");
    if(!player.season||typeof player.season!=="object") player.season={};
    if(!player.career||typeof player.career!=="object") player.career={};
    Object.keys(emptySeason).forEach(key=>{if(player.season[key]==null)player.season[key]=cloneEmptyStatValue(emptySeason[key]);});
    Object.keys(emptyCareer).forEach(key=>{if(player.career[key]==null)player.career[key]=cloneEmptyStatValue(emptyCareer[key]);});
    if(!Array.isArray(player.season.notas)) player.season.notas=[];
    return true;
  }
  function ensureAllPlayerStatsStructures(context){
    const repaired=[];
    Object.values(state.teams||{}).forEach(team=>{
      if(!Array.isArray(team.players)) team.players=[];
      team.players.forEach(player=>{
        const invalid=!player||!player.season||typeof player.season!=="object"||!player.career||typeof player.career!=="object";
        if(ensurePlayerStatsStructure(player)&&invalid)repaired.push({context,pool:"team",teamId:team.id,playerId:player.id||null,playerName:player.name||null,provisional:!!player.__provisional,youthGenerated:!!player.__youthGenerated,loaned:!!player.emprestimo});
      });
    });
    ["freeAgents","inactivePlayers","youthCandidates"].forEach(pool=>{
      if(!Array.isArray(state[pool])) state[pool]=[];
      state[pool].forEach(player=>{
        const invalid=!player||!player.season||typeof player.season!=="object"||!player.career||typeof player.career!=="object";
        if(ensurePlayerStatsStructure(player)&&invalid)repaired.push({context,pool,teamId:null,playerId:player.id||null,playerName:player.name||null,provisional:!!player.__provisional,youthGenerated:!!player.__youthGenerated,loaned:!!player.emprestimo});
      });
    });
    if(repaired.length)console.warn("[HM2027] Estruturas estatísticas reparadas",repaired);
    return repaired;
  }
  function safeStatNumber(value){const number=Number(value);return Number.isFinite(number)?number:0;}
  function completedSeasonTopScorerSnapshot(){
    const entries=[];
    Object.values(state.teams||{}).forEach(team=>(Array.isArray(team.players)?team.players:[]).forEach(player=>{
      if(!player||typeof player!=="object"||player.__provisional)return;
      const season=player.season&&typeof player.season==="object"?player.season:{};
      entries.push({playerId:player.id||null,playerName:player.name||"Jogador desconhecido",teamId:team.id||null,teamName:team.name||"Clube desconhecido",goals:safeStatNumber(season.golos)});
    }));
    entries.sort((a,b)=>b.goals-a.goals||a.playerName.localeCompare(b.playerName,"pt")||String(a.playerId||"").localeCompare(String(b.playerId||"")));
    const leader=entries[0]||null;
    return leader&&leader.goals>0?leader:null;
  }

  // ===================== Prémios de fim de época (2026-09-21) =====================
  // Melhor marcador, melhor jogador e melhor guarda-redes, calculados por competição (agora que
  // participacaoCompeticoes regista golos/assistências/notas/mvp por competição real — Marco U),
  // com reputação de jogador e clube e valorização de mercado escaladas pela importância da
  // competição, e notícia só nas competições em que o clube do utilizador participa.

  // Nível de prestígio: usa reputacaoCompeticao quando a competição vive em state.competitions
  // (ligas — já calibrado, ex. Placard 90, OK Liga 77, Serie A1 65, 2ª Div. 50, 3ª Div. 30-35);
  // as restantes (taças, supertaças, Europa) não têm esse campo — usam regras explícitas por id.
  function seasonAwardTierForCompetition(competitionId){
    const comp = state.competitions[competitionId];
    if(comp && typeof comp.reputacaoCompeticao==="number"){
      if(comp.reputacaoCompeticao>=65) return "A";
      if(comp.reputacaoCompeticao>=45) return "B";
      return "C";
    }
    if(/champions/.test(competitionId)) return "A";
    if(competitionId==="cup") return "B";
    if(["taca-portugal","copa-del-rey","coppa-italia","elite-cup"].includes(competitionId)) return "B";
    return "C"; // trophy, qualif-*, supertaca, supercopa-espana, supercoppa-italiana, outros
  }
  const SEASON_PRIZE_TIER_CONFIG = {
    A:{ repJogador:[3,7], repClube:[1,4], valorJogador:[.08,.16], valorOutros:[.05,.11] },
    B:{ repJogador:[2,4], repClube:[1,3], valorJogador:[.05,.11], valorOutros:[.03,.07] },
    C:{ repJogador:[1,3], repClube:[0,2], valorJogador:[.03,.07], valorOutros:[.02,.05] },
  };

  // Junta, por competição, os números de todos os jogadores que nela participaram esta época —
  // somando entradas repetidas (jogador que joga a mesma competição por dois clubes na mesma
  // época, ex. transferência a meio-época) e ignorando linhas de clubes onde já não está.
  function collectCompetitionParticipation(seasonKey){
    const byCompetition = {};
    Object.values(state.teams).forEach(team=>(team.players||[]).forEach(player=>{
      if(!player||player.__provisional) return;
      const rows = player.participacaoCompeticoes && player.participacaoCompeticoes[seasonKey];
      if(!rows) return;
      const byComp = {};
      Object.values(rows).forEach(r=>{
        if(!r || r.clubeId!==team.id) return;
        const acc = byComp[r.competicaoId] || {jogos:0,golos:0,assistencias:0,mvp:0,notas:[],golosSofridos:0};
        acc.jogos += r.jogos||0; acc.golos += r.golos||0; acc.assistencias += r.assistencias||0;
        acc.mvp += r.mvp||0; acc.golosSofridos += r.golosSofridos||0;
        acc.notas = acc.notas.concat(Array.isArray(r.notas)?r.notas:[]);
        byComp[r.competicaoId] = acc;
      });
      Object.entries(byComp).forEach(([competitionId,acc])=>{
        if(!byCompetition[competitionId]) byCompetition[competitionId]=[];
        byCompetition[competitionId].push({player, team, ...acc});
      });
    }));
    return byCompetition;
  }

  function computeCompetitionAwards(entries){
    const maxJogos = entries.reduce((m,e)=>Math.max(m,e.jogos||0),0);
    const minJogos = Math.max(1, Math.ceil(maxJogos*0.5));
    const elegiveis = entries.filter(e=>(e.jogos||0)>=minJogos);
    const byName=(a,b)=>a.player.name.localeCompare(b.player.name,"pt")||String(a.player.id).localeCompare(String(b.player.id));

    const marcador = elegiveis.slice().sort((a,b)=>
      (b.golos-a.golos) || ((b.golos/b.jogos)-(a.golos/a.jogos)) || byName(a,b)
    )[0];

    const guardaRedes = elegiveis.filter(e=>e.player.pos==="GR").sort((a,b)=>
      ((a.golosSofridos/a.jogos)-(b.golosSofridos/b.jogos)) || (a.golosSofridos-b.golosSofridos) || (b.jogos-a.jogos) || byName(a,b)
    )[0];

    // O Melhor Jogador nunca é um guarda-redes que não seja também o Melhor Guarda-Redes da prova.
    const candidatosJogador = elegiveis.filter(e=>e.player.pos!=="GR" || (guardaRedes && e.player.id===guardaRedes.player.id));
    const jogador = (candidatosJogador.length?candidatosJogador:elegiveis).slice().sort((a,b)=>{
      const perf=(e)=> (e.jogos/maxJogos)*8 + e.golos*.35 + e.assistencias*.25 + e.mvp*.5 + ((e.notas.length?avg(e.notas):6)-6)*3;
      return (perf(b)-perf(a)) || byName(a,b);
    })[0];

    return { marcador, guardaRedes, jogador };
  }

  // Atribui os efeitos de um prémio a um único jogador/clube: título permanente, reputação
  // imediata do jogador (não passa pela mistura de closeCompletedSeasonPlayerStats, que já
  // correu antes de awardEndOfSeasonPrizes), reputação do clube, e valorização direta de
  // mercado — tudo com jitter uniforme determinístico (seed por jogador/clube + prémio +
  // competição + época), nunca um valor fixo.
  function grantSeasonAward(entry, competitionId, tier, awardType, label){
    const { player, team } = entry;
    const season = seasonLabel(state.season);
    const cfg = SEASON_PRIZE_TIER_CONFIG[tier];
    const compLabel = (typeof competitionLabel==="function") ? competitionLabel(competitionId) : competitionId;
    const tituloTexto = `${label} — ${compLabel} ${season}`;
    if(!Array.isArray(player.titulos)) player.titulos=[];
    if(!player.titulos.includes(tituloTexto)) player.titulos.push(tituloTexto);

    const repRng = makeSeededRng(`${player.id}|premio-rep|${competitionId}|${season}|${awardType}`);
    const repBump = seededRndFloat(repRng, cfg.repJogador[0], cfg.repJogador[1]);
    player.reputacaoJogador = clamp((player.reputacaoJogador||0)+repBump, 0, 100);

    if(team){
      const repClubeRng = makeSeededRng(`${team.id}|premio-rep-clube|${competitionId}|${season}|${awardType}`);
      const repClubeBump = seededRndFloat(repClubeRng, cfg.repClube[0], cfg.repClube[1]);
      const before = team.reputacaoPontos!=null ? team.reputacaoPontos : normalizeClubReputation(team.reputacao, team);
      const after = clamp(before+repClubeBump, 5, 99);
      team.reputacaoPontos = after;
      team.reputacao = reputationFromPoints(after);
    }

    const valorRange = awardType==="jogador" ? cfg.valorJogador : cfg.valorOutros;
    const valorRng = makeSeededRng(`${player.id}|premio-valor|${competitionId}|${season}|${awardType}`);
    const pct = seededRndFloat(valorRng, valorRange[0], valorRange[1]);
    const valorAtual = playerMarketValue(player, team);
    player.valorPremioBonus = (player.valorPremioBonus||0) + Math.round(valorAtual*pct);

    if(competitionIsRelevantToUser(competitionId)){
      const compHtml = (typeof competitionLinkHtml==="function") ? competitionLinkHtml(competitionId) : escapeHtml(compLabel);
      pushNews(state.currentDate, `${playerLinkHtml(team.id,player)} venceu o prémio de ${label} de ${compHtml} (${season}), do ${teamLinkHtml(team.id)}.`, "sistema", `Prémios de Fim de Época — ${compLabel}`);
    }
  }

  // Ponto de entrada, chamado em beginDefeso() logo a seguir a closeCompletedSeasonPlayerStats()
  // — os dados de participacaoCompeticoes desta época ainda estão intactos (essa função só
  // reinicia player.season, nunca participacaoCompeticoes), e o bónus de reputação do jogador
  // fica limpo (não diluído pela mistura 55/35/10 dessa função, que já correu).
  function awardEndOfSeasonPrizes(){
    const seasonKey = seasonLabel(state.season);
    const byCompetition = collectCompetitionParticipation(seasonKey);
    const outcomes = [];
    Object.entries(byCompetition).forEach(([competitionId,entries])=>{
      if(!entries.length) return;
      const tier = seasonAwardTierForCompetition(competitionId);
      const { marcador, guardaRedes, jogador } = computeCompetitionAwards(entries);
      if(marcador) grantSeasonAward(marcador, competitionId, tier, "marcador", "Melhor Marcador");
      if(guardaRedes) grantSeasonAward(guardaRedes, competitionId, tier, "guardaRedes", "Melhor Guarda-Redes");
      if(jogador) grantSeasonAward(jogador, competitionId, tier, "jogador", "Melhor Jogador");
      outcomes.push({competitionId,tier,marcador:!!marcador,guardaRedes:!!guardaRedes,jogador:!!jogador});
    });
    return outcomes;
  }

  function beginDefeso(){
    if(state.inDefeso) return;
    ensureAllPlayerStatsStructures("beginDefeso:antes-do-snapshot");
    const topScorerSnapshot=completedSeasonTopScorerSnapshot();
    state.inDefeso = true;
    // Jogadores reais da nuvem (France/Argentina): época doméstica sintética antes de qualquer leitura de jogos/notas.
    if(typeof nuvemReaisSeedSeason==="function") nuvemReaisSeedSeason();
    // Seleções Nacionais (2026-09-26): a CONVOCATÓRIA (pickNationalSquad) tem de correr ANTES de
    // closeCompletedSeasonPlayerStats() — essa função reinicia player.season (a fonte da "forma"
    // usada na convocatória) logo a seguir; se a seleção corresse depois, a forma estaria sempre
    // neutra para toda a gente (ver "Ponto de disparo" no plano aprovado em Plan Mode, 2026-09-26).
    // Correção (2026-09-27, "o jogo tem de começar com a noticia da convocatória... depois vemos
    // as noticias dos jogos"): só prepara a edição aqui (seleciona convocados, monta calendário) —
    // NÃO publica nenhuma notícia ainda, porque state.currentDate ainda não avançou para a
    // pré-época nova (só o faz mais abaixo, "novaData"). announceSelecoesEdicaoIfPending() (a
    // publicação do sorteio+convocatória, datada do dia certo) só corre depois desse salto — ver
    // mais abaixo, perto de "state.currentDate = novaData". As restantes jornadas/eliminatórias
    // resolvem-se dia a dia (processSelecoesForCurrentDate, 07-playoff.js), nunca aqui.
    if(typeof prepareSelecoesEdicaoForNewSeason==="function") prepareSelecoesEdicaoForNewSeason();
    try { if(typeof fbSnapshot==="function") fbSnapshot(); } catch(e){ console.warn("[HM2027] fbSnapshot", e); }
    closeCompletedSeasonPlayerStats();
    // Prémios de fim de época (melhor marcador/jogador/guarda-redes, por competição): corre logo
    // a seguir a closeCompletedSeasonPlayerStats() — participacaoCompeticoes desta época ainda
    // está intacta (só player.season foi reiniciado), e o bónus de reputação do jogador fica
    // limpo, sem ser diluído pela mistura que essa função já aplicou.
    awardEndOfSeasonPrizes();
    // Calibração: os empréstimos que terminam nesta época devem regressar ANTES de qualquer
    // passagem de mercado, para o jogador ficar imediatamente disponível para um novo
    // empréstimo na mesma transição — nada deve impedir isso, e a ordem antiga (regresso só em
    // finalizeNewSeason, depois de todas as passagens já terem corrido) obrigava a esperar uma
    // época inteira antes de ele voltar a ser considerado.
    returnSeasonLoans();
    processDefesoMarket();
    processAiToAiMarket();
    // Reformas e Novas Gerações: primeiro efetiva as reformas já anunciadas e avalia novas
    // decisões (secções 1-4), depois traz a geração anual de jovens de cada clube (secções
    // 5/6/8/9) — sempre depois do mercado, para não interferir com as necessidades de carências
    // já resolvidas. Uma passagem final de segurança garante que ninguém fica abaixo dos
    // mínimos de plantel só por causa de uma reforma.
    processRetirements();
    cleanupFreeAgentPool();
    // Academia e Juvenis (Fase 2, 2026-09-22): substitui generateNewGeneration por completo —
    // admissão anual (só no Sub-13) + cascata de escalões. generateNewGeneration/
    // qualidadeFormacao/youthIntegrationLimit/generateYouthOutfield/generateYouthGoalkeeper/
    // CLUB_FORMATION_QUALITY/initFormationQuality/youthCountForFormation foram removidas de
    // 01-nucleo.js na Fase 5 (2026-09-22) — ensureBTeamMinimums, mais abaixo, já usa os
    // equivalentes da Academia (generateAcademyOutfield/GK, academy.level).
    runAcademyAnnualIntake();
    try { if(typeof fbGerar==="function") fbGerar(); } catch(e){ console.warn("[HM2027] fbGerar", e); }
    Object.values(state.teams).forEach(t=>ensureRosterMinimumsFromFreeAgents(t));
    // Correção (auditoria, bug crítico #2): a equipa B, sem contratações externas, podia ir
    // ficando com plantéis de 2, 3 ou 4 jogadores sem qualquer rede de segurança (só o caso
    // extremo do guarda-redes já estava protegido). Corre depois da rede de segurança da A, para
    // já ter em conta os jogadores que a A libertou/recebeu nesta mesma transição.
    ensureBTeamMinimums();
    ensureAllPlayerStatsStructures("beginDefeso:depois-dos-movimentos");
    applyPromotionAndRelegation();
    if(!state.financePrizeAwarded){ awardSeasonFinances(); distributeSolidarityFund(); state.financePrizeAwarded=true; }
    updateReputations();
    // Correção (auditoria, bug alto #7): esta passagem também deixava as equipas B alterarem a
    // sua própria capacidadeFinanceira/massaAdepta/desempenhoRecente/reputacaoClube com base no
    // seu próprio resultado desportivo — exactamente o que a auditoria assinala como "aparecem
    // como entidades independentes em vários cálculos". A equipa B continua a ter estatísticas e
    // classificação desportiva próprias (isso é normal e desejável), mas estes quatro campos são
    // institucionais e continuam a pertencer ao clube principal.
    Object.values(state.teams).forEach(t=>{
      if(t.equipaPrincipalId) return;
      syncClubStrategicProfile(t);const c=seasonEndCompetitionOf(t.id),tb=c?seasonEndTable(c.id):[],pos=tb.findIndex(x=>x.id===t.id),perf=pos>=0?clamp(90-pos/Math.max(1,tb.length-1)*70,15,90):35;t.desempenhoRecente=roundDecimal(t.desempenhoRecente*.55+perf*.45);t.reputacaoClube=roundDecimal(clamp(t.reputacaoClube*.92+t.reputacaoPontos*.08,5,99));const pr=state.promotionEvent&&((state.promotionEvent.promoted||[]).includes(t.id)||(state.promotionEvent.promotedFromThird||[]).includes(t.id)),re=state.promotionEvent&&((state.promotionEvent.relegated||[]).includes(t.id)||(state.promotionEvent.relegatedToThird||[]).includes(t.id));t.capacidadeFinanceira=roundDecimal(clamp(t.capacidadeFinanceira+(pr?5:re?-4:(perf-50)*.025),5,99));t.massaAdepta=roundDecimal(clamp(t.massaAdepta+(pr?2.5:re?-1.5:(perf-50)*.012),5,99));});
    // Fase 15: avaliação anual da direção e do patrocinador, calculada ainda com as estatísticas
    // da época que está a terminar (antes de developPlayer/resetStats as apagar).
    Object.values(state.teams).forEach(t=>recordDirectionEvaluation(t));
    patrocinioFimDeEpoca();
    persFimDeEpoca();
    arbitroFimDeEpoca();
    // Carreira do treinador (2026-09-05): usa a avaliação da direção que acabou de ser registada
    // para atualizar a reputação pessoal, verificar segurança no cargo, e gerar eventuais
    // propostas de outros clubes — sempre depois da avaliação, nunca antes.
    processManagerCareerSeasonEnd(state.currentDate);
    // Eleições presidenciais (2026-10-14, 08y-presidentes.js): depois da avaliação anual e do balanço do
    // treinador; os objetivos da próxima época (finalizeNewSeasonTail) já refletem o presidente novo.
    presEleicoes(state.currentDate);
    const completedSummary={
      ...(state.promotionEvent||{}),
      champion:(state.userCompetitionId==="ok-liga-2026-27"?state.okLigaChampion:state.userCompetitionId==="serie-a1-2026-27"?state.serieA1Champion:state.placardChampion)||(state.promotionEvent&&state.promotionEvent.champion)||null,
      topScorerName:topScorerSnapshot?topScorerSnapshot.playerName:null,
      topScorerGoals:topScorerSnapshot?topScorerSnapshot.goals:0,
      topScorerPlayerId:topScorerSnapshot?topScorerSnapshot.playerId:null,
      topScorerTeamId:topScorerSnapshot?topScorerSnapshot.teamId:null,
      topScorerTeamName:topScorerSnapshot?topScorerSnapshot.teamName:null,
      // Supertaça António Livramento: a qualificação da próxima edição (campeão nacional +
      // vencedor da Taça, ou o finalista se o mesmo clube tiver feito a dobradinha) precisa
      // destes dois valores da época que está mesmo a terminar — capturados aqui porque
      // initTacaPortugal() (chamado logo a seguir, em finalizeNewSeason) reinicia
      // state.tacaPortugal.campeao/runnerUp para a época nova. Ver 07c-supertaca.js.
      tacaVencedorId: state.tacaPortugal ? state.tacaPortugal.campeao : null,
      tacaFinalistaId: state.tacaPortugal ? state.tacaPortugal.runnerUp : null,
      // Supercopa de España / Supercoppa Italiana (07f-supertacas-internacionais.js): tal como
      // tacaVencedorId/tacaFinalistaId acima, capturados AQUI (antes de initSupercopaEspana/
      // initSupercoppaItaliana reiniciarem os respetivos estados para a época nova, em
      // finalizeNewSeason). Os campeões/vices da OK Liga e da Serie A1 são globais (corridos por
      // IA em segundo plano quando não é o país escolhido pelo utilizador — ver
      // PLAYOFF_DIVISION_CONFIG, 07-playoff.js), por isso ficam sempre disponíveis, qualquer que
      // seja o país da carreira. okLigaStandingsIds guarda a tabela final completa da OK Liga só
      // para o caso-limite de o vencedor da Copa del Rey coincidir com o vice-campeão da liga (ou
      // situação semelhante) — nesse caso a vaga livre da Supercopa passa para o classificado
      // seguinte (ver computeSupercopaEspanaQualification).
      okLigaChampionId: state.okLigaChampion || null,
      okLigaRunnerUpId: state.okLigaRunnerUp || null,
      okLigaStandingsIds: state.competitions["ok-liga-2026-27"] ? seasonEndTable("ok-liga-2026-27").map(t=>t.id) : null,
      // Competições Europeias (07g-europa.js): classificação final completa da Serie A1 (a OK
      // Liga já tinha okLigaStandingsIds, capturado para outro efeito; a Placard já tem
      // placardFullStandingsIds, capturado em applyPromotionAndRelegation, 07-playoff.js).
      serieA1StandingsIds: state.competitions["serie-a1-2026-27"] ? standingsForCompetition("serie-a1-2026-27").map(t=>t.id) : null,
      // Correção (bug real reportado pelo utilizador, 2026-10-04: campeão do Playoff a acabar na
      // WSE Cup em vez da Champions League) — campeão/vice de cada país, por nome de campo
      // inequívoco (o campo genérico "champion" acima, acima, varia consoante o país da carreira
      // do utilizador, por isso não serve para repartir vagas europeias de PAÍSES que não sejam o
      // dele). Usados por europaCountryClubRanking (07g-europa.js) para promover o campeão (e o
      // vice, quando seguido) ao topo da classificação doméstica antes de repartir as vagas.
      placardChampionId: state.placardChampion || null,
      serieA1RunnerUpId: state.serieA1RunnerUp || null,
      copaDelReyVencedorId: (state.copaDelRey && state.copaDelRey.edicao && state.copaDelRey.edicao.epoca===state.season && state.copaDelRey.edicao.fase==="concluida") ? state.copaDelRey.edicao.campeao : (state.copaDelRey && (state.copaDelRey.historico||[]).find(e=>e.epoca===state.season) || {}).campeao || null,
      copaDelReyFinalistaId: (state.copaDelRey && state.copaDelRey.edicao && state.copaDelRey.edicao.epoca===state.season && state.copaDelRey.edicao.fase==="concluida") ? state.copaDelRey.edicao.runnerUp : (state.copaDelRey && (state.copaDelRey.historico||[]).find(e=>e.epoca===state.season) || {}).runnerUp || null,
      serieA1ChampionId: state.serieA1Champion || null,
      coppaItaliaVencedorId: (state.coppaItalia && state.coppaItalia.edicao && state.coppaItalia.edicao.epoca===state.season && state.coppaItalia.edicao.fase==="concluida") ? state.coppaItalia.edicao.campeao : (state.coppaItalia && (state.coppaItalia.historico||[]).find(e=>e.epoca===state.season) || {}).campeao || null,
      coppaItaliaFinalistaId: (state.coppaItalia && state.coppaItalia.edicao && state.coppaItalia.edicao.epoca===state.season && state.coppaItalia.edicao.fase==="concluida") ? state.coppaItalia.edicao.runnerUp : (state.coppaItalia && (state.coppaItalia.historico||[]).find(e=>e.epoca===state.season) || {}).runnerUp || null,
      seasonLabel: seasonLabel(state.season),
    };
    state.lastSeasonSummary=completedSummary;
    state.pendingSeasonSummary=completedSummary;
    // Fase 15 (revisto): a partir daqui o jogo fica parado numa data de defeso real (mercado
    // aberto a transferências) em vez de saltar logo para a nova época — o utilizador pode ir
    // ao Mercado negociar livremente e só avança quando quiser.
    // Correção (calendário sem saltos, pedido explícito do utilizador, 2026-09-14): mesma mudança
    // que no arranque da 1.ª carreira (ver chooseClub, 05-ui-navegacao.js) — a época seguinte
    // passa a começar sempre a 1 de setembro (seasonStartDate, 01-nucleo.js), já sem depender da
    // data da Elite Cup. state.season ainda não foi incrementado aqui (só em finalizeNewSeason,
    // chamado a seguir a este ecrã) — por isso usa-se state.season+1.
    // Correção (bug real, reportado pelo utilizador: vários clubes recorrem a jogadores
    // provisórios logo nos primeiros jogos da nova época, mesmo com plantel completo e 2
    // guarda-redes): este salto de data ia diretamente para o início da época seguinte SEM
    // correr dailyConditionRecovery() para os dias de defeso saltados — e é só ali que
    // diasLesao é decrementado (ver 09-fluxo-epoca.js). Lesões do fim da época anterior
    // ficavam "congeladas" e continuavam a impedir a convocação de jogadores já recuperados na
    // realidade, depois de meses de defeso. Decrementa aqui, de uma vez, o número de dias de
    // defeso — mesmo efeito colateral de dailyConditionRecovery (limpa lesaoInfo ao recuperar).
    const novaData = seasonStartDate(state.season+1);
    recoverInjuriesDuringDefeso(state.currentDate, novaData);
    state.currentDate = novaData;
    state.marketLastRefreshSeason = null; // força a recriação do mercado com os plantéis já resolvidos
    // Seleções Nacionais: só agora, com state.currentDate já no dia certo (1 de setembro da nova
    // pré-época), é que a notícia de sorteio+convocatória (preparada mais acima) é publicada — ver
    // comentário junto de prepareSelecoesEdicaoForNewSeason().
    if(typeof announceSelecoesEdicaoIfPending==="function") announceSelecoesEdicaoIfPending();
    renderHubDate();
    const continuarBtnEl=document.getElementById("continuarBtn");
    if(continuarBtnEl){ continuarBtnEl.disabled=false; continuarBtnEl.textContent="Avançar para a nova época"; }
    renderDefesoModal();
  }
  const defesoGoToMarketBtn=document.getElementById("defesoGoToMarketBtn");
  if(defesoGoToMarketBtn) defesoGoToMarketBtn.addEventListener("click", () => {
    document.getElementById("defesoModal").classList.add("hidden");
    if(typeof mercadoIrPara === "function") mercadoIrPara("negociacoes");
    setView("mercado");
  });

  function finalizeNewSeason(){
    // Reage a carências que o próprio utilizador tenha criado durante esta janela de mercado
    // (ex.: um empréstimo que deixou um clube com só 1 GR) — o regresso de empréstimos já
    // aconteceu antes, logo no início do beginDefeso, para dar tempo a uma nova saída na mesma
    // transição.
    processAiToAiMarketReactive();
    const completedSummary = state.pendingSeasonSummary || {};
    const topScorerName = completedSummary.topScorerName, topScorerGoals = completedSummary.topScorerGoals;
    resetStats();
    state.season += 1;
    // Cópia da época fechada (seasonStatsForDecision) já não é precisa — não pesar no save.
    Object.values(state.teams).forEach(t=>(t.players||[]).forEach(p=>{
      delete p.__seasonFechada; delete p.__seasonFechadaEpoca;
      // 2026-10-16: empréstimos ativos na época nova contam a partir de 0 — as rondas e as
      // estatísticas da época recomeçam; um empréstimo fechado no defeso ficava com rondaInicio = 26
      // (cláusula de utilização mínima e alertas nunca funcionavam).
      if(p.emprestimo){ p.emprestimo.rondaInicio=0; p.emprestimo.jogosInicio=0; p.emprestimo.golosInicio=0; p.emprestimo.titularInicio=0; p.emprestimo.notasInicio=0; }
    }));
    (state.freeAgents||[]).forEach(p=>{ delete p.__seasonFechada; delete p.__seasonFechadaEpoca; });
    state.presEpocaNovaDesde = state.season;   // objetivos da direção: época nova ainda por jogar (presEpocaFechada)
    // Fase: as três competições (Placard, 2ª Divisão Norte, 2ª Divisão Sul) são sempre
    // regeneradas e têm as suas datas atribuídas diretamente aqui, nunca através dos
    // getters/setters state.fixtures/assignFixtureDates (que só apontam para a competição onde
    // o utilizador está neste preciso momento). A versão antiga gerava sempre o novo calendário
    // com as equipas do Placard e escrevia-o, através do setter, na competição do utilizador —
    // se o utilizador gerisse um clube da 2ª Divisão, isso substituía o calendário da sua zona
    // por um cheio de equipas do Placard, e a própria competição do Placard podia nunca chegar
    // a ter datas atribuídas. Bug real, confirmado num caso concreto (HCP Grândola, 2ª Divisão
    // Zona Sul, ficou preso na "Jornada 1" de 8 de novembro com a data real já em janeiro).
    ["placard-2026-27","ok-liga-2026-27","serie-a1-2026-27","2div-norte-2026-27","2div-sul-2026-27","ok-liga-plata-norte-2026-27","ok-liga-plata-sul-2026-27","3div-norte-a-2026-27","3div-norte-b-2026-27","3div-sul-a-2026-27","3div-sul-b-2026-27"].forEach(compId=>{
      const comp = state.competitions[compId];
      if(!comp) return;
      comp.epoca = state.season;
      comp.fixtures = generateValidatedFixtures(comp.teamIds);
      comp.currentRound = 0;
      comp.status = "regular";
      assignFixtureDatesFor(comp);
      // Correção: o sorteio do calendário de uma nova época nunca gerava nenhuma notícia.
      pushNews(state.currentDate, `Sorteio do calendário do ${competitionLinkHtml(compId)} para a época ${seasonLabel(state.season)} realizado — ${comp.teamIds.length} clubes, ${comp.fixtures.length} jornadas.`, "sistema");
    });
    initTacaPortugal();
    // Supertaça António Livramento: emparelha o campeão nacional e o vencedor da Taça (ou o
    // finalista, em caso de dobradinha) apurados na época que acabou de terminar — a partir da
    // 2ª carreira em diante (a 1ª edição, sem época anterior, é tratada em chooseClub()).
    initSupertaca({ summary: completedSummary });
    // Elite Cup (07d-elite-cup.js): qualificação a partir do top 8 do Campeonato Placard da
    // época que acabou de terminar (completedSummary.placardTop8, capturado em
    // applyPromotionAndRelegation antes de promoções/despromoções serem aplicadas).
    initEliteCup({ summary: completedSummary });
    // Supercopa de España e Supercoppa Italiana (07f-supertacas-internacionais.js): qualificação a
    // partir dos campeões/vencedores da OK Liga/Copa del Rey e Serie A1/Coppa Italia da época que
    // acabou de terminar (completedSummary, capturado em beginDefeso). Copa del Rey/Coppa Italia
    // não precisam de nada aqui — apuram-se sozinhas a meio da época nova, assim que a OK
    // Liga/Serie A1 completarem a 1ª volta (ver maybeStartNationalCup, 07e-copas-nacionais.js).
    initSupercopaEspana({ summary: completedSummary });
    initSupercoppaItaliana({ summary: completedSummary });
    // Competições Europeias (07g-europa.js): quotas por país recalculadas a partir do coeficiente
    // (histórico de pontos das últimas 5 épocas europeias) e das classificações domésticas finais
    // da época que acabou de terminar, capturadas em completedSummary.
    europaInitEdition({ summary: completedSummary });
    state.financePrizeAwarded = false;
    Object.values(state.teams).forEach(t=>{
      if(t.equipaPrincipalId)return;
      initClubFinance(t);const f=t.financeiro,st=financialState(t);
      if(!Array.isArray(f.historicoEpocas))f.historicoEpocas=[];
      const row={epoca:seasonLabel(state.season-1),saldoInicial:f.saldoInicialEpoca||0,saldoFinal:f.saldo||0,receitas:f.receitasEpoca||0,despesas:f.despesasEpoca||0,resultado:(f.receitasEpoca||0)-(f.despesasEpoca||0),dividaInicial:f.dividaInicialEpoca||0,dividaFinal:(f.divida||0)+(f.creditoUtilizado||0),juros:f.encargosFinanceirosEpoca||0,estadoFinal:st.id,massaSalarial:monthlyWageBill(t)};
      closeFinanceAuditSeason(t,row.epoca);
      const idx=f.historicoEpocas.findIndex(x=>x.epoca===row.epoca);if(idx>=0)f.historicoEpocas[idx]=row;else f.historicoEpocas.push(row);
      f.saldoInicialEpoca=f.saldo;f.dividaInicialEpoca=(f.divida||0)+(f.creditoUtilizado||0);f.receitasEpoca=0;f.despesasEpoca=0;f.encargosFinanceirosEpoca=0;
    });
    // Elite Cup: se a edição foi gerada (o clube do utilizador pode não estar entre os 8
    // qualificados — o caso mais comum) e ainda não está concluída, resolve-se agora mesmo; o
    // resto desta transição de época (arranque efetivo do calendário, resumo de época) só
    // continua depois de a prova terminar — ver eliteCupRunPostSequence, 07d-elite-cup.js.
    if(!eliteCupEditionConcluded()){
      state.eliteCupPostSequence = "newSeasonTail";
      // Correção (bug real, reportado pelo utilizador): antes, state.inDefeso ficava "herdado" a
      // true durante toda a Elite Cup — só finalizeNewSeasonTail o desligava, quando a prova
      // terminava — porque a prova inteira se resolvia sempre de imediato, nesta mesma chamada,
      // sem qualquer clique extra em "Continuar" pelo meio. Agora que currentDate está sempre 1
      // semana antes dos quartos de final (ver mais acima) e a Elite Cup só se resolve dia a dia,
      // à medida que o calendário lá chega (ver processPhaseFiveFinalsForCurrentDate, em
      // 07-playoff.js), manter inDefeso a true aqui faria o clique seguinte em "Continuar"
      // reentrar nesta função do zero (state.season+=1 outra vez!) em vez de avançar um dia —
      // por isso desliga-se já aqui, tal como finalizePreSeasonDefeso já fazia na 1.ª carreira.
      state.inDefeso = false;
      // Resumo de fim de época mostrado já, no momento da transição (2026-10-16, "isto apareceu
      // no final da Elite Cup"): antes só saía na cauda, semanas depois, com a época nova a decorrer.
      completedSummary.__mostrado = true;
      // O ecrã de defeso (#defesoModal), aberto por beginDefeso() antes de sabermos que havia
      // Elite Cup para resolver, ficava visível por cima de tudo, incluindo a convocatória do
      // próprio jogo da Elite Cup — um modal-overlay bloqueia sempre os cliques nos elementos por
      // baixo, esteja o que estiver lá. Resultado: os clubes que apuravam para a Elite Cup na
      // nova época ficavam presos no ecrã de defeso, sem conseguirem nem disputar a eliminatória
      // nem aceder à Central de Contratos/Mercado (que também fica tapada pelo overlay). A lógica
      // de carregamento de save (applySaveObjectUnchecked, 11-guardar-carregar.js) já evitava
      // mostrar este modal quando detectava uma Elite Cup pendente — replica-se aqui a mesma
      // correção para o fluxo normal, sem gravar/carregar o jogo.
      const defesoModalEl = document.getElementById("defesoModal");
      if(defesoModalEl) defesoModalEl.classList.add("hidden");
      processEliteCupForCurrentDate();
      renderHubDate();
      showSeasonSummary(completedSummary);
      return;
    }
    finalizeNewSeasonTail(completedSummary);
  }
  // Cauda da transição de época — extraída de finalizeNewSeason para poder ser adiada até a
  // Elite Cup terminar (ver acima). completedSummary já inclui topScorerName/topScorerGoals
  // (ver a sua construção em beginDefeso).
  function finalizeNewSeasonTail(completedSummary){
    completedSummary = completedSummary || {};
    const topScorerName = completedSummary.topScorerName, topScorerGoals = completedSummary.topScorerGoals;
    const topScorerTeamId = completedSummary.topScorerTeamId, topScorerPlayerId = completedSummary.topScorerPlayerId;
    state.seasonOver = false;
    state.presEpocaNovaDesde = null;
    state.seasonOverSinceDate = null; state.seasonCloseStuckWarned = false; state.seasonCloseWaitSince = null;
    presGerarTodos();   // objetivos da direção da época nova (08y-presidentes.js)
    if(typeof derbyNovaEpoca==="function") derbyNovaEpoca();   // rivalidade acumulada dos Clássicos (08ze-classicos.js)
    state.match = null; state.pendingFixture = null;
    state.playoffActive = false;
    state.playoff = null;
    state.pendingPlayoffSeries = null;
    state.playoffClinchedAnnounced = false;
    state.promotionTie=null; state.pendingPromotionTieGameIndex=null; state.plataTie=null; state.pendingPlataTieGameIndex=null; state.placardChampion=null; state.okLigaChampion=null; state.serieA1Champion=null;
    state.okLigaRunnerUp=null; state.serieA1RunnerUp=null;
    state.secondDivisionFinal=null; state.pendingSecondDivisionFinalGameIndex=null;
    state.terceiraDivisaoZoneWinners=null; state.terceiraDivisaoZoneTables=null; state.userZonaCompetitionId=null; state.terceiraDivisaoResultadoProcessado=null;
    state.pendingTacaPortugalFase=null; state.pendingTacaPortugalIndex=null;
    state.seasonTransitionApplied=false; state.transferMarket=[]; state.marketLastRefreshSeason=null;
    rebuildGlobalAgenda();
    initPreSeasonPlan();
    state.pendingAgendaEventId = null;
    // Correção (calendário sem saltos, pedido explícito do utilizador, 2026-09-14): esta função
    // saltava state.currentDate diretamente para 5 dias antes da 1ª jornada, ignorando por
    // completo as semanas entre o fim da Elite Cup (agora em fim de setembro) e outubro — sem
    // processar nada dia a dia nesse intervalo. state.currentDate fica onde a Elite Cup o deixou
    // (eliteCupRunPostSequence, 07d-elite-cup.js, já garante que está, no mínimo, na data da
    // final) — o próximo "Continuar" entra no ciclo normal de avanço diário (09-fluxo-epoca.js),
    // que já paga finanças, resolve negociações e trata a Elite Cup dia a dia, chegando sozinho à
    // 1ª jornada quando o calendário lá chegar. Mesma correção já feita em
    // finalizePreSeasonLeagueStart (05-ui-navegacao.js), para a 1ª carreira.
    // Refresca a duração (em anos, para exibição) de todos os contratos face à nova data.
    Object.values(state.teams).forEach(t=>t.players.forEach(p=>{ if(p.contrato) p.contrato.anos = Math.max(0, Math.round(contractYearsRemaining(p.contrato))); }));
    document.getElementById("continuarBtn").disabled = false;
    document.getElementById("continuarBtn").textContent = "▶ Continuar";
    state.inDefeso = false;
    expirePendingAiOffers(state.currentDate);
    state.pendingSeasonSummary = null;
    const defesoModalEl = document.getElementById("defesoModal");
    if(defesoModalEl) defesoModalEl.classList.add("hidden");
    setView("clube");
    renderAll();
    // Correção (pedido do utilizador, 2026-09-17: notícias com jogadores devem ser clicáveis):
    // o jogador continua no plantel da equipa (o fim de época não remove ninguém, só reformas
    // explícitas já tratadas à parte) — só recorre ao nome simples se, por algum motivo, já não
    // for possível encontrá-lo.
    const topScorerTeam = topScorerTeamId ? state.teams[topScorerTeamId] : null;
    const topScorerPlayerObj = topScorerTeam ? topScorerTeam.players.find(p=>p.id===topScorerPlayerId) : null;
    const topScorerLink = topScorerPlayerObj ? playerLinkHtml(topScorerTeamId,topScorerPlayerObj) : escapeHtml(topScorerName||"");
    const scorerTxt = topScorerName ? `Melhor marcador da época: ${topScorerLink} (${topScorerGoals} golos). ` : "";
    pushNews(state.currentDate, `Início da Época ${seasonLabel(state.season)}! ${scorerTxt}Todos os jogadores envelheceram +1 ano e desenvolveram os seus atributos.`, "sistema");
    if(!completedSummary.__mostrado) showSeasonSummary(completedSummary);
  }

  // =================================================================
