// Lesões com tipologia e relatórios do departamento médico (2026-10-12, pedido do utilizador: "o
// relatório do departamento clínico sobre lesões tem de ter o mesmo aspeto do relatório pré-jogo;
// desenvolve o relatório médico com tipos de lesões").
//
// Decisões confirmadas por ele:
//   - Tipologia com efeitos: cada lesão tem tipo e zona do corpo (rotura muscular, entorse do
//     tornozelo, fratura, concussão, ligamentos do joelho…); a duração das lesões graves sai da
//     gama do tipo; cada tipo tem o seu risco de recaída; guarda-redes e jogadores de campo têm
//     catálogos/pesos diferentes. Sem sequelas permanentes.
//   - Recaída ao voltar cedo: depois da alta há uma fase de readaptação em que o risco de lesão
//     é maior (e uma lesão nessa fase é, quase sempre, recaída da anterior).
//   - Plano de recuperação: normal, acelerada (menos dias, mais risco) ou prudente (mais dias,
//     menos risco), escolhido no boletim do diagnóstico e alterável enquanto o jogador estiver parado.
//   - Relatório mensal do plantel pelo departamento médico.
//
// Estado: p.lesaoInfo (tipoId, zona, plano, diasTotal…), p.readapt, p.lesoesLog (últimas 14) e
// state.lesoes = { v, mes } (relatório mensal). Tudo em dados simples, guardado com o resto.

const LES_TIPOS = Object.freeze({
  // ---- graves (dias de paragem entre min e max; recaida = risco extra de lesão logo após a alta)
  rotura_muscular: { id:"rotura_muscular", nome:"Rotura muscular", familia:"muscular", grave:true, peso:26, min:8, max:34, recaida:3.0,
    zonas:["coxa (isquiotibiais)","adutores","gémeo","quadricípite"], zonasGR:["adutores","coxa (isquiotibiais)"],
    mecanismo:"esforço máximo numa arrancada ou travagem", tratamento:"crioterapia, fisioterapia progressiva e trabalho de força excêntrico" },
  entorse_tornozelo: { id:"entorse_tornozelo", nome:"Entorse do tornozelo", familia:"ligamentar", grave:true, peso:16, min:8, max:40, recaida:2.0,
    zonas:["tornozelo"], zonasGR:["tornozelo"], mecanismo:"torção do pé na mudança de direção ou no contacto", tratamento:"imobilização curta, drenagem e reforço proprioceptivo" },
  tendinite: { id:"tendinite", nome:"Tendinite", familia:"tendinosa", grave:true, peso:9, min:8, max:28, recaida:3.0,
    zonas:["tendão rotuliano","tendão de Aquiles"], zonasGR:["tendão rotuliano"], mecanismo:"sobrecarga repetida (carga de treino e jogo acumulada)", tratamento:"descanso relativo, ondas de choque e fortalecimento gradual" },
  concussao: { id:"concussao", nome:"Concussão", familia:"neurológica", grave:true, peso:7, min:7, max:18, recaida:1.5,
    zonas:["cabeça"], zonasGR:["cabeça"], pesoGR:1.4, mecanismo:"choque com a bola, o stick ou o piso", tratamento:"repouso e protocolo de regresso gradual, sem contacto até alta neurológica" },
  fratura: { id:"fratura", nome:"Fratura", familia:"óssea", grave:true, peso:10, min:28, max:75, recaida:0.8,
    zonas:["pulso","clavícula","costelas","mão"], zonasGR:["mão/dedos","pulso"], pesoGR:1.6, mecanismo:"impacto direto (bolada, stick ou queda)", tratamento:"imobilização, consolidação óssea e fisioterapia de recuperação da mobilidade" },
  lig_joelho: { id:"lig_joelho", nome:"Lesão de ligamentos do joelho", familia:"ligamentar", grave:true, peso:6, min:60, max:160, recaida:2.5,
    zonas:["joelho (ligamento cruzado)","joelho (ligamento colateral)"], zonasGR:["joelho (ligamento colateral)"], mecanismo:"torção do joelho com o pé fixo no piso", tratamento:"estabilização, fisioterapia intensiva e reforço muscular prolongado" },
  menisco: { id:"menisco", nome:"Lesão do menisco", familia:"articular", grave:true, peso:7, min:35, max:100, recaida:2.0,
    zonas:["joelho"], zonasGR:["joelho"], mecanismo:"rotação brusca com o joelho em carga", tratamento:"descarga articular, fisioterapia e, se necessário, intervenção minimamente invasiva" },
  luxacao_ombro: { id:"luxacao_ombro", nome:"Luxação do ombro", familia:"articular", grave:true, peso:5, min:28, max:80, recaida:2.0,
    zonas:["ombro"], zonasGR:["ombro"], pesoGR:1.8, mecanismo:"queda sobre o braço ou choque com a balaustrada", tratamento:"redução, imobilização e reforço da coifa dos rotadores" },
  pubalgia: { id:"pubalgia", nome:"Pubalgia", familia:"muscular", grave:true, peso:6, min:18, max:60, recaida:3.0,
    zonas:["púbis / virilha"], zonasGR:["púbis / virilha"], pesoGR:1.6, mecanismo:"mudanças de direção repetidas e desequilíbrio abdominal-adutores", tratamento:"descanso ativo, fisioterapia e fortalecimento do core" },
  lombar: { id:"lombar", nome:"Lesão lombar", familia:"vertebral", grave:true, peso:4, min:18, max:70, recaida:2.5,
    zonas:["zona lombar"], zonasGR:["zona lombar"], mecanismo:"queda ou esforço em flexão", tratamento:"repouso, analgesia e programa de estabilização lombar" },
  // ---- ligeiras (só perdem condição física; continuam disponíveis)
  contusao: { id:"contusao", nome:"Contusão", familia:"contusão", grave:false, peso:30,
    zonas:["coxa","canela","ombro","costelas","mão"], zonasGR:["mão","peito","canela","coxa"], mecanismo:"choque com um adversário ou com a balaustrada", tratamento:"gelo, compressão e repouso relativo" },
  caibra: { id:"caibra", nome:"Cãibra / fadiga muscular", familia:"muscular", grave:false, peso:24,
    zonas:["gémeo","coxa","adutores"], zonasGR:["coxa","adutores"], mecanismo:"fadiga acumulada e desidratação", tratamento:"alongamentos, hidratação e massagem de recuperação" },
  entorse_ligeira: { id:"entorse_ligeira", nome:"Entorse ligeira", familia:"ligamentar", grave:false, peso:18,
    zonas:["tornozelo","joelho","pulso"], zonasGR:["tornozelo","pulso"], mecanismo:"torção sem rotura de fibras", tratamento:"gelo, ligadura funcional e fisioterapia" },
  pancada: { id:"pancada", nome:"Pancada de bola ou stick", familia:"contusão", grave:false, peso:18, pesoGR:2.4,
    zonas:["canela","pé","mão"], zonasGR:["mão","peito","canela","pé"], mecanismo:"impacto de bola ou de stick", tratamento:"gelo e observação nas horas seguintes" },
  corte: { id:"corte", nome:"Corte / escoriação", familia:"cutânea", grave:false, peso:10,
    zonas:["sobrancelha","queixo","mão"], zonasGR:["mão","queixo"], mecanismo:"contacto com o stick ou queda", tratamento:"limpeza, sutura ou penso e reavaliação" },
});
const LES_PLANOS = Object.freeze({
  normal:    { id:"normal",    label:"Normal",    dias:1.00, risco:1.00, readapt:1.00, desc:"o tempo de paragem recomendado pelo departamento médico" },
  acelerada: { id:"acelerada", label:"Acelerada", dias:0.75, risco:1.80, readapt:1.40, desc:"menos 25% de dias parado, mas readaptação mais longa e maior risco de recaída" },
  prudente:  { id:"prudente",  label:"Prudente",  dias:1.20, risco:0.45, readapt:0.80, desc:"mais 20% de dias parado, com risco de recaída muito reduzido" },
});
const LES_READAPT_FRAC = 0.25, LES_READAPT_MIN = 3, LES_READAPT_MAX = 21;
const LES_RECAIDA_PROB = 0.65, LES_RECAIDA_DUR = 1.25;
const LES_LOG_MAX = 14;

function lesTipo(id) { return LES_TIPOS[id] || null; }
function lesRandInt(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
function lesEnsure() {
  if (!state.lesoes || typeof state.lesoes !== "object") state.lesoes = { v: 1, mes: null, mesB: null };
  return state.lesoes;
}
function lesZonas(tipo, p) { return (p && p.pos === "GR" ? tipo.zonasGR : tipo.zonas) || tipo.zonas; }
function lesZonaAleatoria(tipo, p) { const z = lesZonas(tipo, p); return z[Math.floor(Math.random() * z.length)]; }
function lesPlano(info) { return LES_PLANOS[info && info.plano] || LES_PLANOS.normal; }

// Escolhe o tipo: graves ou ligeiras, com pesos que dependem da posição, idade, condição e carga.
function lesEscolherTipo(p, team, gravidade, opts) {
  opts = opts || {};
  const gr = p && p.pos === "GR";
  const cond = p && p.condicao != null ? p.condicao : 100;
  const velho = p && (p.age || 24) >= 31;
  const carga = typeof cargaValor === "function" ? cargaValor(p) : 0;
  let lista = Object.values(LES_TIPOS).filter(t => t.grave === (gravidade === "grave"));
  if (opts.maxDias) { const ok = lista.filter(t => t.min <= opts.maxDias * 1.5); if (ok.length) lista = ok; }
  const pesos = lista.map(t => {
    let w = t.peso * (gr && t.pesoGR ? t.pesoGR : 1);
    if (gr && (t.id === "tendinite" || t.id === "lig_joelho" || t.id === "menisco")) w *= 0.5;   // guarda-redes correm menos
    if (["rotura_muscular", "tendinite", "lombar", "caibra"].includes(t.id)) { if (cond < 60) w *= 1.5; if (velho) w *= 1.3; }
    if (t.id === "tendinite" && carga >= 50) w *= 1.8;
    return w;
  });
  let r = Math.random() * pesos.reduce((a, b) => a + b, 0);
  for (let i = 0; i < lista.length; i++) { r -= pesos[i]; if (r <= 0) return lista[i]; }
  return lista[lista.length - 1];
}
function lesDuracaoBase(tipo) { return lesRandInt(tipo.min, tipo.max); }

function lesLog(p, e) {
  if (!Array.isArray(p.lesoesLog)) p.lesoesLog = [];
  p.lesoesLog.unshift(e);
  if (p.lesoesLog.length > LES_LOG_MAX) p.lesoesLog.length = LES_LOG_MAX;
}
function lesHistorialTexto(p, tipo, zona) {
  const log = Array.isArray(p.lesoesLog) ? p.lesoesLog : [];
  const epoca = log.filter(x => x.epoca === state.season);
  const dias = epoca.reduce((a, x) => a + (x.dias || 0), 0);
  const mesmaZona = log.slice(1).filter(x => x.zona === zona).length;
  const partes = [];
  partes.push(epoca.length > 1 ? `${epoca.length} lesões nesta época (${dias} dias parado)` : "primeira lesão desta época");
  if (mesmaZona) partes.push(`<b>${mesmaZona}</b> anterior${mesmaZona > 1 ? "es" : ""} na mesma zona: fragilidade a vigiar`);
  if ((p.lesoesGraves || 0) > 1) partes.push(`${p.lesoesGraves} lesões graves na carreira`);
  return partes.join(" · ");
}

// ---------------------------------------------------------------- Origem (jogo, estágio)
function lesOrigemJogo(ctx, side) {
  if (!ctx) return { tipo: "treino" };
  const opp = side === "home" ? ctx.awayId : ctx.homeId;
  const per = ctx.period === 1 ? "1.ª parte" : ctx.period === 2 ? "2.ª parte" : "prolongamento";
  const min = Math.floor((ctx.clock || 0) / 60) + 1;
  return { tipo: "jogo", oppId: opp, quando: `${per}, ${min}.º minuto`, amigavel: !!ctx.isFriendly };
}
function lesOrigemTexto(o, info) {
  if (info && info.recaida) return "recaída da lesão anterior";
  if (!o) return "treino";
  if (o.tipo === "jogo") return `no jogo com ${o.oppId && state.teams[o.oppId] ? teamLinkHtml(o.oppId) : "o adversário"} (${o.quando})${o.amigavel ? ", de preparação" : ""}`;
  if (o.tipo === "estagio") return "durante o estágio de pré-época";
  return "em treino";
}

// ---------------------------------------------------------------- Aplicar lesões
// opts: { origem, recaida, dias (duração já calculada, sem diagnóstico pendente) }
function lesAplicarGrave(p, team, opts) {
  opts = opts || {};
  const isUser = team.id === state.userTeamId;
  p.lesoesGraves = (p.lesoesGraves || 0) + 1;
  if (opts.origem && opts.origem.tipo === "jogo") p.__lesaoGraveNestaPartida = true;   // não volta a pista nesta partida
  const rd = p.readapt;
  const recaida = !!opts.recaida && rd && lesTipo(rd.tipoId);
  const tipo = recaida ? lesTipo(rd.tipoId) : lesEscolherTipo(p, team, "grave", { maxDias: opts.dias });
  const zona = recaida ? rd.zona : lesZonaAleatoria(tipo, p);
  const medMult = medicalDurationMult(team);
  const baseDias = opts.dias != null ? opts.dias : lesDuracaoBase(tipo) * (recaida ? LES_RECAIDA_DUR : 1);
  p.readapt = null;
  const info = { gravidade: "grave", tipoId: tipo.id, zona, dataInicio: isoDate(state.currentDate), origem: opts.origem || { tipo: "treino" },
    recaida: !!recaida, plano: "normal", diasBase: Math.round(baseDias), medMult };
  if (isUser && opts.dias == null) {
    p.diasLesao = 1;
    info.diagnosticoPendente = true;
    p.lesaoInfo = info;
    if (!Array.isArray(state.pendingMedicalEvaluations)) state.pendingMedicalEvaluations = [];
    const delay = medicalDiagnosisDelayDays(team);
    info.respostaDias = delay;
    state.pendingMedicalEvaluations.push({ playerId: p.id, teamId: team.id, resolveDate: isoDate(addDays(state.currentDate, delay)), medMult });
    lesLog(p, { epoca: state.season, data: info.dataInicio, tipoId: tipo.id, zona, gravidade: "grave", dias: 0, recaida: !!recaida });
    pushNews(state.currentDate, lesRelatorioHtml(p, team, recaida ? "recaida" : "pendente"), "clinico", `${recaida ? "Recaída" : "Lesão grave"}: ${p.name}`, { autoAdvanceStop: true, teamId: team.id });
  } else {
    const dias = Math.max(1, Math.round(opts.dias != null ? opts.dias : baseDias * medMult));
    p.diasLesao = dias;
    info.diagnosticoPendente = false; info.diasTotal = dias;
    p.lesaoInfo = info;
    lesLog(p, { epoca: state.season, data: info.dataInicio, tipoId: tipo.id, zona, gravidade: "grave", dias, recaida: !!recaida });
    if (isUser) pushNews(state.currentDate, lesRelatorioHtml(p, team, "diagnostico"), "clinico", `${opts.origem && opts.origem.tipo === "estagio" ? "Lesão no estágio" : "Diagnóstico"}: ${p.name}`, { autoAdvanceStop: true, teamId: team.id });
  }
  return info;
}
function lesAplicarLigeira(p, team, opts) {
  opts = opts || {};
  const isUser = team.id === state.userTeamId;
  const tipo = lesEscolherTipo(p, team, "ligeira");
  const zona = lesZonaAleatoria(tipo, p);
  const loss = clamp(clamp(randNormalApprox(30, 15), INJURY_LIGEIRA_LOSS_MIN, INJURY_LIGEIRA_LOSS_MAX) * medicalLightLossMult(team), 4, INJURY_LIGEIRA_LOSS_MAX);
  p.condicao = roundDecimal(clamp((p.condicao != null ? p.condicao : 100) - loss, 0, 100));
  p.lesaoInfo = null;
  lesLog(p, { epoca: state.season, data: isoDate(state.currentDate), tipoId: tipo.id, zona, gravidade: "ligeira", dias: 0, recaida: false });
  if (isUser) pushNews(state.currentDate, lesRelatorioHtml(p, team, "ligeira", { tipo, zona, loss, origem: opts.origem }), "clinico", `Lesão ligeira: ${p.name}`, { autoAdvanceStop: true, teamId: team.id });
}
// Garante tipo numa lesão grave guardada por uma versão anterior (sem tipoId).
function lesGarantirTipo(p, team) {
  const info = p.lesaoInfo;
  if (!info || info.gravidade !== "grave" || info.tipoId) return info;
  const tipo = lesEscolherTipo(p, team, "grave");
  info.tipoId = tipo.id; info.zona = lesZonaAleatoria(tipo, p); info.plano = info.plano || "normal"; info.origem = info.origem || { tipo: "treino" };
  return info;
}
// Chamado pelo diagnóstico pendente (06-motor-jogo.js) quando chega o dia da resposta.
function lesResolverDiagnostico(p, team, item) {
  const info = lesGarantirTipo(p, team);
  const base = info.diasBase != null ? info.diasBase : lesDuracaoBase(lesTipo(info.tipoId));
  const dias = Math.max(1, Math.round(base * (item.medMult || info.medMult || 1)));
  p.diasLesao = dias;
  p.lesaoInfo = Object.assign({}, info, { diagnosticoPendente: false, diasTotal: dias, dataDiagnostico: isoDate(state.currentDate) });
  const e = (p.lesoesLog || []).find(x => x.data === info.dataInicio && x.gravidade === "grave" && !x.dias);
  if (e) e.dias = dias;
  return p.lesaoInfo;
}

// ---------------------------------------------------------------- Plano de recuperação
function lesMudarPlano(playerId, plano) {
  const team = myTeam();
  const p = team && team.players.find(x => x.id === playerId);
  if (!p || !p.lesaoInfo || p.lesaoInfo.gravidade !== "grave" || !p.lesaoInfo.tipoId) return { ok: false, reason: "Este jogador já não está lesionado." };
  if (p.lesaoInfo.diagnosticoPendente) return { ok: false, reason: "O diagnóstico ainda não está concluído." };
  if (!LES_PLANOS[plano]) return { ok: false, reason: "Plano inválido." };
  if ((p.diasLesao || 0) < 2) return { ok: false, reason: "A recuperação está quase concluída." };
  const atual = lesPlano(p.lesaoInfo), novo = LES_PLANOS[plano];
  if (atual.id === novo.id) return { ok: true, inalterado: true };
  const f = novo.dias / atual.dias;
  p.diasLesao = Math.max(1, Math.round(p.diasLesao * f));
  p.lesaoInfo.diasTotal = Math.max(p.diasLesao, Math.round((p.lesaoInfo.diasTotal || p.diasLesao) * f));
  p.lesaoInfo.plano = novo.id;
  return { ok: true, dias: p.diasLesao };
}

// ---------------------------------------------------------------- Alta e readaptação
function lesRecuperou(p, team) {
  const info = p.lesaoInfo;
  if (!info || info.gravidade !== "grave" || !info.tipoId) return;
  const tipo = lesTipo(info.tipoId); if (!tipo) return;
  const plano = lesPlano(info);
  const dias = Math.max(LES_READAPT_MIN, Math.round(clamp(Math.round((info.diasTotal || 10) * LES_READAPT_FRAC), LES_READAPT_MIN, LES_READAPT_MAX) * plano.readapt));
  const risco = Math.round(tipo.recaida * plano.risco * medicalInjuryMult(team) * 100) / 100;
  p.readapt = { tipoId: tipo.id, zona: info.zona, dias, total: dias, risco, plano: plano.id };
  if (team.id === state.userTeamId) pushNews(state.currentDate, lesRelatorioHtml(p, team, "regresso", { info }), "clinico", `Alta médica: ${p.name}`, { teamId: team.id });
}
function lesDiaPassou(p) {
  if (!p.readapt) return;
  p.readapt.dias -= 1;
  if (p.readapt.dias <= 0) p.readapt = null;
}
// Multiplicador do risco de lesão em jogo: máximo logo após a alta, a descer até ao fim da readaptação.
function lesReadaptMult(p) {
  const r = p && p.readapt;
  if (!r) return 1;
  return 1 + r.risco * clamp(r.dias / Math.max(1, r.total), 0, 1);
}
function lesRiscoNivel(m) { return m >= 3 ? "elevado" : m >= 1.8 ? "moderado" : "baixo"; }

// ---------------------------------------------------------------- Relatórios (formato folha)
function lesJogosEmFalta(team, dias) {
  try {
    const comp = state.competitions[state.userCompetitionId];
    if (!comp || !comp.fixtures) return null;
    const hoje = calHoje(), fim = calIsoAdd(hoje, dias);
    let n = 0;
    comp.fixtures.forEach(round => {
      if (!round || !round.date) return;
      const d = isoDate(round.date);
      if (d > hoje && d <= fim && round.some(f => f.home === team.id || f.away === team.id)) n++;
    });
    return n;
  } catch (e) { return null; }
}
function lesSubstituto(team, p) {
  const livres = team.players.filter(q => q.id !== p.id && playerAvailableForMatch(q) && (q.condicao == null || q.condicao >= 60));
  if (p.pos === "GR") return livres.filter(q => q.pos === "GR").sort((a, b) => overall(b) - overall(a))[0] || null;
  return livres.filter(q => q.pos === "J" && !q.titular && q.linha === p.linha).sort((a, b) => overall(b) - overall(a))[0] ||
    livres.filter(q => q.pos === "J" && !q.titular).sort((a, b) => overall(b) - overall(a))[0] || null;
}
function lesDataRegresso(dias) { return fmtDateLong(addDays(state.currentDate, dias)); }
function lesPlanoBotoes(p, info) {
  const atual = lesPlano(info).id, base = Math.round((info.diasTotal || p.diasLesao || 0) / lesPlano(info).dias);
  return `<div class="les-planos">${Object.values(LES_PLANOS).map(pl =>
    `<button type="button" class="les-plano-btn${pl.id === atual ? " on" : ""}" data-pid="${p.id}" data-plano="${pl.id}" data-inicio="${info.dataInicio}">${pl.label}<small>${Math.max(1, Math.round(base * pl.dias))} dias</small></button>`).join("")}</div>`;
}
function lesBadgeNivel(team) {
  const cfg = medicalLevelConfig(team), nivel = ensureTeamMedico(medicalOwnerTeam(team)).nivel;
  return { nivel, label: cfg.label, dur: Math.round((cfg.durationMult - 1) * 100), risco: Math.round((cfg.injuryMult - 1) * 100) };
}
function lesEfeitoMed(med) { return med.dur === 0 && med.risco === 0 ? "nível de referência (sem bónus nem penalização)" : `duração das lesões graves ${lesPct(med.dur)}, risco de lesão ${lesPct(med.risco)}`; }
function lesPct(v) { return `${v > 0 ? "+" : ""}${v}%`; }

// estado: "ligeira" | "pendente" | "recaida" | "diagnostico" | "regresso"
function lesRelatorioHtml(p, team, estado, x) {
  x = x || {};
  const info = p.lesaoInfo || x.info || {};
  const tipo = estado === "ligeira" ? x.tipo : lesTipo(info.tipoId);
  const zona = estado === "ligeira" ? x.zona : info.zona;
  const nomeTipo = tipo ? tipo.nome : "Lesão";
  const nome = playerLinkHtml(team.id, p);
  const med = lesBadgeNivel(team);
  const origem = estado === "ligeira" ? lesOrigemTexto(x.origem) : lesOrigemTexto(info.origem, info);
  const hist = tipo ? lesHistorialTexto(p, tipo, zona) : "";
  const subst = lesSubstituto(team, p);
  const secDiag = { icone: "🩺", titulo: "Diagnóstico", linhas: [
    ["Jogador", `${nome} (${p.pos === "GR" ? "guarda-redes" : p.linha === "Avancado" ? "avançado" : "defesa/médio"})`],
    ["Lesão", tipo ? `<b>${tipo.nome}</b>` : "—"],
    ["Zona", zona ? escapeHtml(zona) : "—"],
    ["Natureza", tipo ? tipo.familia : "—"],
    ["Ocorrência", origem],
  ] };
  const secHist = { icone: "🗂️", titulo: "Historial", linhas: [["Do jogador", hist || "—"]] };
  const secMed = { icone: "🏥", titulo: "Departamento médico", linhas: [
    ["Nível", `<b>${med.nivel}</b> · ${med.label}`],
    ["Efeito", lesEfeitoMed(med)],
    ["Tratamento", tipo ? tipo.tratamento : "—"],
  ] };
  const marca = `<span data-les-diag="${p.id}" hidden></span>`;
  if (estado === "ligeira") {
    const cond = Math.round(p.condicao != null ? p.condicao : 100);
    const aviso = cond < 55 ? "Recomenda-se poupar o jogador no próximo jogo." : cond < 75 ? "Convém gerir os minutos nos próximos dias." : "Sem restrições.";
    return repDoc({
      teamId: team.id, org: "Departamento médico", titulo: "Boletim clínico", sub: `Lesão ligeira · ${escapeHtml(p.name)} · ${fmtDateLong(state.currentDate)}`,
      chips: [repChip("Lesão ligeira"), repChip(`−${Math.round(x.loss)}% condição`, "aviso"), repChip("Disponível", "ok"), repChip(`Condição ${cond}%`, cond < 55 ? "mau" : cond < 75 ? "aviso" : "")],
      resumo: `${nome} sofreu ${tipo ? (tipo.nome.charAt(0).toLowerCase() + tipo.nome.slice(1)) : "uma lesão"}${zona ? ` (${escapeHtml(zona)})` : ""}, mas continua disponível. ${aviso}`,
      secoes: [secDiag,
        { icone: "📉", titulo: "Impacto", linhas: [["Condição perdida", `<b>${Math.round(x.loss)}%</b>`], ["Condição atual", `<b>${cond}%</b>`], ["Disponibilidade", "disponível para a próxima convocatória"], ["Recomendação", aviso]] },
        secHist, secMed],
      rodape: "Boletim clínico · departamento médico" + marca,
    });
  }
  const jogos = estado === "diagnostico" ? lesJogosEmFalta(team, p.diasLesao || 0) : null;
  const substLinha = subst ? `${playerLinkHtml(team.id, subst)} (${Math.round(overall(subst))} OVR)` : "sem alternativa disponível";
  if (estado === "pendente" || estado === "recaida") {
    const rec = estado === "recaida";
    const delay = info.respostaDias != null ? info.respostaDias : 2;
    return repDoc({
      teamId: team.id, org: "Departamento médico", titulo: rec ? "Recaída: avaliação em curso" : "Lesão grave: avaliação em curso", sub: `${escapeHtml(p.name)} · ${fmtDateLong(state.currentDate)}`,
      chips: [repChip(rec ? "Recaída" : "Lesão grave", "mau"), repChip("A aguardar diagnóstico", "aviso"), repChip(`Resposta em ${delay} dia${delay > 1 ? "s" : ""}`), repChip("Indisponível", "mau")],
      resumo: `${nome} saiu de pista com ${rec ? "uma recaída" : "uma lesão grave"}${zona ? ` (${escapeHtml(zona)})` : ""}. O departamento médico faz os exames e define o tempo de paragem nos próximos dias.`,
      secoes: [
        { icone: "🚑", titulo: "Ocorrência", linhas: [["Jogador", `${nome} · ${p.pos === "GR" ? "guarda-redes" : p.linha === "Avancado" ? "avançado" : "defesa/médio"}`], ["Local", escapeHtml(zona || "—")], ["Natureza provável", tipo ? tipo.familia : "—"], ["Como", origem], ["Estado", "indisponível desde já"]] },
        { icone: "🔬", titulo: "Próximos passos", linhas: [["Exames", "avaliação clínica e imagiologia"], ["Diagnóstico", `em ${delay} dia${delay > 1 ? "s" : ""}, segundo o nível do departamento (${med.label})`], ["Plano", "depois do diagnóstico escolhes o plano de recuperação"]] },
        { icone: "🎯", titulo: "Impacto no plantel", linhas: [["Substituto sugerido", substLinha]] },
        secHist],
      rodape: "Boletim clínico · departamento médico" + marca,
    });
  }
  if (estado === "diagnostico") {
    const plano = lesPlano(info), dias = p.diasLesao || info.diasTotal || 0;
    const rd = tipo ? Math.max(LES_READAPT_MIN, Math.round(clamp(Math.round((info.diasTotal || dias) * LES_READAPT_FRAC), LES_READAPT_MIN, LES_READAPT_MAX) * plano.readapt)) : 0;
    const risco = tipo ? Math.round(tipo.recaida * plano.risco * medicalInjuryMult(team) * 100) / 100 : 0;
    const dur = formatInjuryDuration(dias);
    return repDoc({
      teamId: team.id, org: "Departamento médico", titulo: "Diagnóstico clínico", sub: `${escapeHtml(p.name)} · ${fmtDateLong(state.currentDate)}`,
      chips: [repChip(nomeTipo, "mau"), repChip(`Fora cerca de ${dur}`, "aviso"), repChip(`Regresso a ${fmtDateShort(addDays(state.currentDate, dias))}`), repChip(`Plano ${plano.label.toLowerCase()}`)],
      resumo: `${nome} tem ${tipo ? tipo.nome.toLowerCase() : "uma lesão"}${zona ? ` (${escapeHtml(zona)})` : ""} e vai ficar de fora cerca de <b>${dur}</b>. Ao regressar, ${rd} dias de readaptação com risco de lesão ${lesRiscoNivel(1 + risco)}.`,
      secoes: [secDiag,
        { icone: "📅", titulo: "Recuperação", linhas: [
          ["Paragem", dur === `${dias} dia${dias > 1 ? "s" : ""}` ? `<b>${dur}</b>` : `<b>${dur}</b> (${dias} dias)`],
          ["Regresso previsto", lesDataRegresso(dias)],
          ["Jogos em falta", jogos != null ? (jogos ? `cerca de <b>${jogos}</b> jogo${jogos === 1 ? "" : "s"} da liga` : "nenhum jogo oficial da liga") : "—"],
          ["Plano de recuperação", `${lesPlanoBotoes(p, info)}<div class="les-plano-desc">${plano.label}: ${plano.desc}.</div>`],
          ["Readaptação", `${rd} dias após a alta, com risco de lesão até <b>×${(1 + risco).toFixed(1)}</b> (${lesRiscoNivel(1 + risco)}), a descer até ao fim`],
        ] },
        { icone: "🎯", titulo: "Impacto no plantel", linhas: [["Substituto sugerido", substLinha]] },
        secMed, secHist],
      detalhes: tipo ? [{ titulo: "Como se deu e como se trata", html: `Esta lesão resulta, em regra, de ${tipo.mecanismo}. Tratamento previsto: ${tipo.tratamento}.` }] : [],
      rodape: "Diagnóstico clínico · departamento médico" + marca,
    });
  }
  // regresso
  const r = p.readapt || { dias: 0, risco: 0, plano: "normal", total: 1 };
  return repDoc({
    teamId: team.id, org: "Departamento médico", titulo: "Alta médica", sub: `${escapeHtml(p.name)} · ${fmtDateLong(state.currentDate)}`,
    chips: [repChip("Recuperado", "ok"), repChip(`Readaptação ${r.dias} dias`, "aviso"), repChip(`Risco ×${(1 + r.risco).toFixed(1)}`, r.risco >= 2 ? "mau" : "aviso"), repChip(`Plano ${lesPlano({ plano: r.plano }).label.toLowerCase()}`)],
    resumo: `${nome} teve alta e pode voltar à convocatória, mas está em readaptação durante ${r.dias} dias: o risco de lesão é ${lesRiscoNivel(1 + r.risco)} (×${(1 + r.risco).toFixed(1)}) logo agora e desce até ao fim.`,
    secoes: [
      { icone: "✅", titulo: "Alta", linhas: [["Jogador", nome], ["Lesão", `<b>${nomeTipo}</b>${zona ? ` (${escapeHtml(zona)})` : ""}`], ["Paragem total", info.diasTotal ? formatInjuryDuration(info.diasTotal) : "—"], ["Plano seguido", lesPlano(info).label]] },
      { icone: "🩹", titulo: "Readaptação", linhas: [["Duração", `${r.dias} dias`], ["Risco de lesão", `<b>×${(1 + r.risco).toFixed(1)}</b> no primeiro dia, a descer até ao normal`], ["Recomendação", r.risco >= 2 ? "dar minutos curtos e evitar jogos de grande desgaste" : "gerir os minutos nos primeiros jogos"], ["Se houver nova lesão", "provavelmente é uma recaída, com paragem mais longa"]] },
      secHist, secMed],
    rodape: "Alta médica · departamento médico",
  });
}
// Troca de plano a partir do botão do boletim: atualiza o jogador e refaz o boletim.
function lesRefazerBoletim(p, team) {
  const marca = `data-les-diag="${p.id}"`;
  const n = state.news.find(x => x.kind === "clinico" && typeof x.text === "string" && x.text.includes(marca) && x.text.includes("Diagnóstico clínico"));
  if (n) n.text = lesRelatorioHtml(p, team, "diagnostico");
}

// ---------------------------------------------------------------- Textos curtos (plantel e ficha)
function lesTituloRoster(p) {
  const info = p.lesaoInfo || {}, t = lesTipo(info.tipoId);
  if (info.diagnosticoPendente) return "Lesionado: a aguardar diagnóstico";
  return `Lesionado${t ? ": " + t.nome.toLowerCase() + (info.zona ? " (" + info.zona + ")" : "") : ""} · falta ${p.diasLesao} dia${p.diasLesao > 1 ? "s" : ""}`;
}
function lesTituloReadapt(p) {
  const r = p.readapt; if (!r) return "";
  return `Em readaptação: risco de lesão ×${lesReadaptMult(p).toFixed(1)} durante mais ${r.dias} dia${r.dias > 1 ? "s" : ""}`;
}
function lesBannerTexto(p) {
  const info = p.lesaoInfo || {}, t = lesTipo(info.tipoId);
  if (info.diagnosticoPendente) return `Lesão grave${t ? "" : ""}: a aguardar diagnóstico do departamento médico`;
  const base = info.gravidade === "grave" ? "Lesão grave" : "Lesão ligeira";
  return `${t ? t.nome : base}${info.zona ? " (" + info.zona + ")" : ""} · falta ${p.diasLesao} dia${p.diasLesao > 1 ? "s" : ""}${info.recaida ? " · recaída" : ""}${info.plano && info.plano !== "normal" ? " · plano " + lesPlano(info).label.toLowerCase() : ""}`;
}

// ---------------------------------------------------------------- Secção "Saúde do plantel" (relatório do adjunto)
function lesSecaoSaudeHtml(team) {
  if (!team) return null;
  const nome = p => playerLinkHtml(team.id, p);
  const les = team.players.filter(p => (p.diasLesao || 0) > 0);
  const rd = team.players.filter(p => p.readapt && !((p.diasLesao || 0) > 0));
  if (!les.length && !rd.length) return null;
  const linhas = [];
  if (les.length) linhas.push(["Lesionados", les.map(p => {
    const info = p.lesaoInfo || {}, t = lesTipo(info.tipoId);
    return `${nome(p)} (${info.diagnosticoPendente ? "a aguardar diagnóstico" : `${t ? t.nome.toLowerCase() + ", " : ""}${formatInjuryDuration(p.diasLesao)}`})`;
  }).join(", ")]);
  if (rd.length) linhas.push(["Em readaptação", rd.map(p => `${nome(p)} (risco ×${lesReadaptMult(p).toFixed(1)}, ${p.readapt.dias} dia${p.readapt.dias > 1 ? "s" : ""})`).join(", ")]);
  return { icone: "🩺", titulo: "Saúde do plantel", linhas };
}

// ---------------------------------------------------------------- Relatório mensal do plantel
// Relatório mensal do departamento médico. Sem argumentos: equipa principal do utilizador.
// Com a equipa B (08x-equipa-b.js): o mesmo relatório para o plantel B, com chave mensal própria.
function lesMensal(equipaB) {
  const team = equipaB || myTeam(); if (!team || !state.currentDate) return;
  const c = lesEnsure(), chave = equipaB ? "mesB" : "mes";
  const mes = `${state.currentDate.getFullYear()}-${String(state.currentDate.getMonth() + 1).padStart(2, "0")}`;
  if (c[chave] === mes) return;
  c[chave] = mes;
  const nome = p => playerLinkHtml(team.id, p);
  const les = team.players.filter(p => (p.diasLesao || 0) > 0).sort((a, b) => b.diasLesao - a.diasLesao);
  const rd = team.players.filter(p => p.readapt && !((p.diasLesao || 0) > 0));
  const risco = team.players.filter(p => !((p.diasLesao || 0) > 0) && ((p.condicao != null ? p.condicao : 100) < 70 || (typeof cargaValor === "function" && cargaValor(p) >= 60)))
    .sort((a, b) => (a.condicao != null ? a.condicao : 100) - (b.condicao != null ? b.condicao : 100)).slice(0, 5);
  const logs = [];
  team.players.forEach(p => (p.lesoesLog || []).filter(x => x.epoca === state.season).forEach(x => logs.push(Object.assign({ p }, x))));
  const porTipo = {};
  logs.forEach(x => { const t = lesTipo(x.tipoId); if (t) porTipo[t.nome] = (porTipo[t.nome] || 0) + 1; });
  const tipos = Object.keys(porTipo).sort((a, b) => porTipo[b] - porTipo[a]).slice(0, 3).map(n => `${n} (${porTipo[n]})`);
  const diasPerdidos = logs.reduce((a, x) => a + (x.dias || 0), 0);
  const graves = logs.filter(x => x.gravidade === "grave").length, recaidas = logs.filter(x => x.recaida).length;
  const med = lesBadgeNivel(team);
  const linhaLes = p => { const info = p.lesaoInfo || {}, t = lesTipo(info.tipoId); return `${nome(p)} · ${info.diagnosticoPendente ? "a aguardar diagnóstico" : `${t ? t.nome.toLowerCase() : "lesão"}${info.zona ? " (" + escapeHtml(info.zona) + ")" : ""}, regresso a ${fmtDateShort(addDays(state.currentDate, p.diasLesao))}, plano ${lesPlano(info).label.toLowerCase()}`}`; };
  const resumo = les.length ? `${les.length} jogador${les.length > 1 ? "es" : ""} lesionado${les.length > 1 ? "s" : ""}${rd.length ? `, ${rd.length} em readaptação` : ""}.` : (rd.length ? `Ninguém lesionado; ${rd.length} jogador${rd.length > 1 ? "es" : ""} em readaptação.` : "Sem lesionados nem jogadores em readaptação.");
  pushNews(state.currentDate, repDoc({
    teamId: team.id, org: "Departamento médico", titulo: equipaB ? "Relatório mensal do plantel da equipa B" : "Relatório mensal do plantel", sub: fmtDateLong(state.currentDate),
    chips: [repChip(`${les.length} lesionado${les.length === 1 ? "" : "s"}`, les.length ? "mau" : "ok"), repChip(`${rd.length} em readaptação`, rd.length ? "aviso" : ""), repChip(`${risco.length} em risco`, risco.length ? "aviso" : ""), repChip(`Departamento ${med.label.toLowerCase()}`)],
    resumo,
    secoes: [
      { icone: "🚑", titulo: "Lesionados", cheia: true, linhas: les.length ? les.map(p => ["", linhaLes(p)]) : [["", "nenhum de momento"]] },
      { icone: "🩹", titulo: "Em readaptação", linhas: rd.length ? rd.map(p => [nome(p), `risco ×${lesReadaptMult(p).toFixed(1)} · ${p.readapt.dias} dia${p.readapt.dias > 1 ? "s" : ""}`]) : [["", "ninguém"]] },
      { icone: "⚠️", titulo: "Jogadores em risco", linhas: risco.length ? risco.map(p => [nome(p), `condição ${Math.round(p.condicao != null ? p.condicao : 100)}%${typeof cargaValor === "function" && cargaValor(p) >= 60 ? ` · carga ${Math.round(cargaValor(p))}` : ""}`]) : [["", "ninguém com condição baixa ou carga alta"]] },
      { icone: "📊", titulo: "Balanço da época", linhas: [["Lesões", `<b>${logs.length}</b> (${graves} grave${graves === 1 ? "" : "s"}${recaidas ? `, ${recaidas} recaída${recaidas > 1 ? "s" : ""}` : ""})`], ["Dias perdidos", `${diasPerdidos}`], ["Mais frequentes", tipos.length ? tipos.join(", ") : "—"]] },
      { icone: "🏥", titulo: "Departamento médico", linhas: [["Nível", `<b>${med.nivel}</b> · ${med.label}`], ["Encargo mensal", equipaB ? "partilhado com a equipa principal" : fmtMoney(monthlyMedicalCost(team))], ["Efeito", lesEfeitoMed(med)]] },
    ],
    rodape: "Relatório mensal · departamento médico",
  }), "clinico", equipaB ? "Relatório mensal do departamento médico (equipa B)" : "Relatório mensal do departamento médico");
}

// ---------------------------------------------------------------- Cliques (botões do plano)
(function wireLesoesUi() {
  document.addEventListener("click", e => {
    const b = e.target && e.target.closest ? e.target.closest(".les-plano-btn") : null;
    if (!b) return;
    const team = myTeam(), p = team && team.players.find(x => x.id === b.getAttribute("data-pid"));
    if (!p || !p.lesaoInfo || p.lesaoInfo.dataInicio !== b.getAttribute("data-inicio")) { if (typeof showTransientNotice === "function") showTransientNotice("Esta lesão já está resolvida."); return; }
    const r = lesMudarPlano(p.id, b.getAttribute("data-plano"));
    if (!r.ok) { if (typeof showTransientNotice === "function") showTransientNotice(r.reason); return; }
    if (!r.inalterado) {
      lesRefazerBoletim(p, team);
      if (typeof showTransientNotice === "function") showTransientNotice(`Plano ${LES_PLANOS[b.getAttribute("data-plano")].label.toLowerCase()} aplicado: regresso em ${r.dias} dia${r.dias > 1 ? "s" : ""}.`);
      if (typeof renderNews === "function") renderNews();
    }
  });
})();
