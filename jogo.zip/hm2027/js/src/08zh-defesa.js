// =====================================================================
// 0.3.4 — Tipo de defesa (Zona 2-2 / Individual / Mista)
//
// Origem: relatório "Táticas e sistemas no hóquei em patins" (outubro 2026) enviado pelo
// utilizador — a defesa zonal 2-2 protege o centro, poupa fôlego e induz remate exterior
// (vulnerável a bons rematadores); a individual dificulta receções e provoca erros, mas gasta
// mais, dá mais faltas e um duelo perdido abre espaço (pior contra bons driblers); a mista
// retira o adversário principal da construção mas tem "zonas cinzentas" sem posicionamento.
//
// TODOS os valores são ESTIMATIVAS de jogo (o relatório não dá números), pequenos de propósito:
// a zona (omissão) é quase neutra no total de golos, para não mexer na calibração do campeonato.
// Dado guardado em team.defesa ("zona" | "individual" | "mista"); omissão = "zona".
// Efeitos (a equipa que DEFENDE é `def`, a que ataca é `att`):
//   - conversão do adversário  (defesaConversionMult)
//   - volume de remates do adversário (defesaShotMult)
//   - desgaste de quem defende (defesaFatigueMult)
//   - faltas/cartões de quem defende (defesaFoulMult)
// A IA escolhe o tipo consoante o plantel (chooseAiDefesa), antes de cada jogo.
// =====================================================================
const DEFESA_TIPOS = Object.freeze({
  zona:       { label:"Zona",       curto:"Protege o centro e poupa fôlego; induz remate exterior e é vulnerável a bons rematadores.",
                bom:"Equipas jovens ou menos rápidas, proteger vantagem, adversários fracos no remate exterior.", mau:"Contra bons rematadores de meia distância e jogadores entre linhas." },
  individual: { label:"Individual", curto:"Dificulta receções e provoca erros, mas cansa mais, dá mais faltas e um duelo perdido abre espaço.",
                bom:"Equipas rápidas, resistentes e agressivas; adversários com pouco drible.", mau:"Contra bons driblers e com defesas lentos ou sem fôlego." },
  mista:      { label:"Mista",      curto:"Um marcador apanha o melhor adversário e os restantes defendem à zona; pede bom posicionamento.",
                bom:"Quando o adversário depende de uma estrela e os teus defesas leem bem o jogo.", mau:"Com defesas fracos de posicionamento (zonas cinzentas entre perseguição e cobertura)." }
});
function defesaTipo(team){ return team && DEFESA_TIPOS[team.defesa] ? team.defesa : "zona"; }
// 0.3.8: a zona toma a forma do sistema da equipa — 3-1 triângulo, 2-2 quadrado, 1-2-1 losango.
function defesaForma(team){ return SISTEMA_FORMA[team && sistemaOk(team.sistema) ? team.sistema : "3-1"]; }
function defesaLosango(team){ return defesaTipo(team)==="zona" && team && team.sistema==="1-2-1"; }
function defesaOutfield(team){ return team ? team.players.filter(p=>p.pos==="J") : []; }
function defesaAvgAttr(players, keys, dflt){
  if(!players.length) return dflt==null ? 12 : dflt;
  const v = players.map(p=>{
    const xs = keys.map(k=>p.attrs && p.attrs[k]!=null ? p.attrs[k] : (dflt==null ? 12 : dflt));
    return xs.reduce((a,b)=>a+b,0)/xs.length;
  });
  return v.reduce((a,b)=>a+b,0)/v.length;
}
// Qualidade de duelo/posição de quem defende (usa os atributos do plantel, não só quem joga).
function defesaDuelQ(team){ return defesaAvgAttr(defesaOutfield(team), ["desarme","velocidade","resistencia","posicionamento"]); }

function defesaConversionMult(att, def){
  const tipo = defesaTipo(def);
  const A = defesaOutfield(att), D = defesaOutfield(def);
  if(tipo==="zona"){
    const shootEdge = clamp((defesaAvgAttr(A, ["meiaDistancia","finalizacao"]) - 13)/6, 0, 1);
    if(defesaLosango(def)){
      // losango: fecha o corredor central (menos conversão), mas deixa mais remate de meia distância
      // se a pressão do vértice avançado falhar; defesas com mau posicionamento abrem "zonas cinzentas".
      const gray = defesaAvgAttr(D, ["posicionamento"]) < 12 ? 1.02 : 1;
      return 0.965 * (1 + 0.09*shootEdge) * gray * ((att && att.sistema==="3-1") ? 1.02 : 1);
    }
    return 0.97 * (1 + 0.07*shootEdge) * ((att && att.sistema==="3-1") ? 1.02 : 1);
  }
  if(tipo==="individual"){
    const dribEdge = clamp((defesaAvgAttr(A, ["drible"]) - 13)/4, -1, 1);
    const duelScale = clamp(defesaDuelQ(def)/13, 0.85, 1.15);
    const weak = duelScale<1 ? 1 + (1-duelScale)*0.2 : 1;
    return (1 + 0.05*dribEdge) * weak * ((att && att.sistema==="3-1") ? 1.02 : 0.99);
  }
  // mista
  const ovrs = A.map(p=>overall(p)); const best = ovrs.length ? Math.max.apply(null, ovrs) : 0;
  const meanOvr = ovrs.length ? ovrs.reduce((a,b)=>a+b,0)/ovrs.length : 0;
  const standout = (best-meanOvr) >= 2 ? 0.985 : 1;
  const gray = defesaAvgAttr(D, ["posicionamento"]) < 12 ? 1.02 : 1;
  return 0.985 * standout * gray;
}
function defesaShotMult(att, def){
  const tipo = defesaTipo(def);
  if(tipo==="zona") return defesaLosango(def) ? 1.07 : 1.05;
  if(tipo==="individual") return 1 - 0.06*clamp(defesaDuelQ(def)/13, 0.85, 1.15);
  return 0.98;
}
function defesaFatigueMult(team){ const t = defesaTipo(team); return t==="zona" ? (defesaLosango(team) ? 0.98 : 0.95) : t==="individual" ? 1.12 : 1.03; }
function defesaFoulMult(team){ const t = defesaTipo(team); return t==="zona" ? (defesaLosango(team) ? 0.93 : 0.90) : t==="individual" ? 1.15 : 1.05; }

// A IA (e a sugestão mostrada ao utilizador) escolhe consoante o que o plantel aguenta.
function defesaSugestao(team){
  const D = defesaOutfield(team);
  if(D.length < 4) return { tipo:"zona", motivo:"plantel curto" };
  const duel = defesaAvgAttr(D, ["desarme","velocidade","resistencia","agressividade"]);
  const pos = defesaAvgAttr(D, ["posicionamento"]);
  let score = duel - 13.5;
  try{ score += (treinadorCulturaOrNeutral(team).agressividade - 10) * 0.2; }catch(e){}
  if(score > 1.2) return { tipo:"individual", motivo:"plantel rápido, resistente e agressivo" };
  if(score > 0.3 && pos >= 13) return { tipo:"mista", motivo:"bom posicionamento e algum músculo nos duelos" };
  return { tipo:"zona", motivo: score < -0.5 ? "plantel menos rápido/resistente" : "equilíbrio entre duelo e posicionamento" };
}
function chooseAiDefesa(team){
  // só para testes automáticos (activo apenas com o interruptor de testes ligado)
  if(typeof window!=="undefined" && window.__HM2027_EXPOSE_TEST_HOOKS__ && window.__HM2027_FORCE_DEFESA) return window.__HM2027_FORCE_DEFESA;
  return defesaSugestao(team).tipo;
}

// Texto sob os botões do separador Táticas (actualizado sempre que o tipo muda).
function defesaHelpHtml(team){
  const t = defesaTipo(team), d = DEFESA_TIPOS[t], s = defesaSugestao(team), sd = DEFESA_TIPOS[s.tipo];
  const rotulo = t==="zona" ? `${d.label} (${defesaForma(team)})` : d.label;
  const extra = defesaLosango(team) ? " No losango, o vértice avançado condiciona o portador e fecha o centro, os alas fecham os flancos e o último defesa vigia o pivot adversário; deixa remates de meia distância se a pressão falhar." : "";
  return `<b>${rotulo}:</b> ${d.curto}${extra}<br><b>Funciona melhor:</b> ${d.bom} <b>Cuidado:</b> ${d.mau}<br>Sugestão para o teu plantel: <b>${sd.label}</b> (${s.motivo}).`;
}
function defesaSyncHelp(){
  const el = document.getElementById("defesaHelp"); const team = myTeam();
  if(el && team) el.innerHTML = defesaHelpHtml(team);
  if(team) document.querySelectorAll('[data-defesa="zona"]').forEach(b=>{ b.textContent = "Zona · " + defesaForma(team); });
}
