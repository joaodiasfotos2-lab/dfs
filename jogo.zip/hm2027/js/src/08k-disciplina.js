// Conselho de Disciplina (2026-10-12, pedido do utilizador: ideia 3 da sexta lista).
// Decisões de desenho confirmadas por ele:
//  - infrações: INCIDENTES COM O PÚBLICO e "tudo de acordo com o regulamento, válido para todas
//    as ligas" — por isso também as expulsões diretas (relatório do árbitro) e a regra de que o
//    3.º azul ou o 2.º amarelo no banco só afetam o próprio jogo (Art. 22.º e 24.º das Regras do
//    Jogo; antes o jogo suspendia o jogador no jogo seguinte em qualquer vermelho);
//  - RECURSO PAGO com resultado incerto; o clube do utilizador é notificado por EMAIL do
//    Conselho de Disciplina; a IA sofre processos e recorre, em todas as ligas.
//
// FONTES E ESTIMATIVAS (a assinalar): o RGHP (Julho 2026) remete o regime disciplinar para o
// Regulamento de Disciplina e a violência para o Regulamento de Prevenção de Violência da FPP —
// nenhum dos dois está no projeto. Do RGHP usa-se: Art. 59.º (promotor responsável pela segurança
// do recinto), Art. 60.º (danos na viatura da equipa de arbitragem pagos pelo clube visitado),
// Art. 77.º (jogo suspenso por incidentes do público → Conselho de Disciplina), multas e taxas em
// múltiplos do salário mínimo nacional à data de início da época (art. 22.º), delegado federativo
// que reporta ao Conselho de Disciplina e substituição de treinador castigado. São ESTIMATIVAS,
// não vindas de regulamento: os múltiplos do salário mínimo de cada multa, a probabilidade de
// incidentes, os jogos extra por expulsão direta, a taxa de recurso e as probabilidades de êxito
// do recurso. O salário mínimo de referência (PT 920 €) e os de Espanha/Itália também.
//
// Dados: team.disciplina = { casos[], portaFechada, incidentesEpoca, epoca, seq } (guardado com a
// equipa; saves antigos criam-no de forma preguiçosa).

const DISC_SMN = { pt: 920, es: 1381, it: 1100 };            // salário mínimo mensal de referência (estimativa)
const DISC_FEDERACAO = { pt: "fpp.pt", es: "rfep.es", it: "fisr.it" };
const DISC_DIAS_DECISAO_JOGADOR = 3;
const DISC_DIAS_DECISAO_CLUBE = 5;
const DISC_DIAS_PRAZO_RECURSO = 2;
const DISC_DIAS_RECURSO = 4;
const DISC_PROB_INCIDENTE_BASE = 0.012;
const DISC_MULTAS_SMN = [1.5, 4, 10];                        // por gravidade 1–3
const DISC_TAXA_RECURSO_SMN = { jogador: 1, clube: 0.5 };

function disciplinaPais(team){ return typeof viagemPais === "function" ? viagemPais(team) : "pt"; }
function disciplinaSMN(team){ return DISC_SMN[disciplinaPais(team)] || DISC_SMN.pt; }
function disciplinaEnsure(team){
  if(!team) return null;
  if(!team.disciplina || typeof team.disciplina !== "object") team.disciplina = { v: 1, casos: [], portaFechada: 0, incidentesEpoca: 0, epoca: null, seq: 0 };
  const d = team.disciplina;
  if(!Array.isArray(d.casos)) d.casos = [];
  if(d.portaFechada == null) d.portaFechada = 0;
  if(d.epoca !== state.season){ d.epoca = state.season; d.incidentesEpoca = 0; }
  return d;
}
function disciplinaSomaDias(date, dias){ const d = new Date(date || state.currentDate); d.setDate(d.getDate() + dias); return d; }
function disciplinaIso(d){ return isoDate(new Date(d || state.currentDate)); }
function disciplinaFmt(iso){ try { return fmtDateShort(new Date(iso)); } catch(e){ return iso; } }
function disciplinaEhUtilizador(team){ return !!team && team.id === state.userTeamId; }
function disciplinaElegivel(team){ return !!team && !!team.financeiro && team.divisaoAtual !== "selecao-nacional"; }
function disciplinaFedEmail(team){ return `disciplina@${DISC_FEDERACAO[disciplinaPais(team)] || DISC_FEDERACAO.pt}`; }
function disciplinaNoticia(team, titulo, texto){
  if(!disciplinaEhUtilizador(team)) return;
  pushNews(state.currentDate, texto, "disciplina", titulo, { sender: disciplinaFedEmail(team) });
}
function disciplinaPortaFechada(team){ const d = team && team.disciplina; return !!(d && (d.portaFechada || 0) > 0); }

function disciplinaNovoCaso(team, base){
  const d = disciplinaEnsure(team);
  d.seq = (d.seq || 0) + 1;
  const caso = Object.assign({ id: `${team.id}-d${d.seq}`, clubeId: team.id, criado: disciplinaIso(), estado: "instaurado", epoca: state.season }, base);
  d.casos.unshift(caso);
  if(d.casos.length > 40) d.casos.length = 40;
  return caso;
}

// ---------------------------------------------------------------------------------------------
// Regra do vermelho (Art. 22.º/24.º): só a expulsão DIRETA suspende o jogador no jogo seguinte e
// gera processo. O vermelho por acumulação (3 azuis, 2 amarelos no banco) afeta só o próprio jogo.
// ---------------------------------------------------------------------------------------------
function disciplinaVermelhoEDireto(player, ctx){
  const azuis = ((player && player.__cardsThisMatch) || []).filter(c => c === "azul").length;
  return azuis < 2;
}
function disciplinaRegistarVermelho(ctx, side, player){
  if(!player) return false;
  const direto = disciplinaVermelhoEDireto(player, ctx);
  if(direto){
    ctx.vermelhosDiretos = ctx.vermelhosDiretos || [];
    ctx.vermelhosDiretos.push({ side, playerId: player.id });
  } else {
    ctx.vermelhosAcumulacao = ctx.vermelhosAcumulacao || [];
    ctx.vermelhosAcumulacao.push({ side, playerId: player.id });
  }
  return direto;
}

// Jogos extra decididos pelo Conselho para uma expulsão direta (estimativa): 0 extra na maioria.
function disciplinaJogosExtra(player){
  const agress = player && player.attrs && player.attrs.agressividade != null ? player.attrs.agressividade : 10;
  const pExtra = clamp(0.26 + (agress - 10) * 0.02, 0.14, 0.5);
  if(Math.random() >= pExtra) return 0;
  const r = Math.random();
  return r < 0.70 ? 1 : r < 0.92 ? 2 : 3;
}

function disciplinaProbIncidente(home, away, ctx){
  let p = DISC_PROB_INCIDENTE_BASE;
  const a = typeof ensureAdeptos === "function" ? ensureAdeptos(home) : null;
  const humor = a ? a.humor : 55;
  p *= humor < 30 ? 4 : humor < 46 ? 2.2 : humor < 62 ? 1.2 : humor >= 78 ? 0.6 : 1;
  if(typeof isDerby === "function" && isDerby(home.id, away.id)) p *= (typeof derbyIntensidade === "function" ? 1 + 1.2 * derbyIntensidade(home.id, away.id) : 2.2);
  if(ctx.isPlayoff) p *= 1.4;
  const cap = home.financeiro && home.financeiro.capacidadePavilhao;
  if(cap && ctx.attendance != null && ctx.attendance >= cap) p *= 1.3;
  if(ctx.score.home < ctx.score.away) p *= 1.8;
  const d = disciplinaEnsure(home);
  p *= 1 + 0.5 * (d.incidentesEpoca || 0);
  return clamp(p, 0, 0.09);
}
const DISC_INCIDENTES = [
  ["Arremesso de objetos para a pista", "Pirotecnia nas bancadas", "Cânticos e insultos dirigidos à equipa de arbitragem"],
  ["Invasão do recinto de jogo por adeptos", "Agressão verbal e ameaças à equipa de arbitragem", "Arremesso de objetos que atingiram um jogador"],
  ["Invasão da pista e confrontos entre adeptos", "Agressão a um elemento da equipa de arbitragem", "Jogo interrompido por incidentes graves nas bancadas"],
];

function disciplinaIncidentePublico(ctx, home, away){
  if(ctx.neutralVenue || ctx.isFriendly) return;
  if(!disciplinaElegivel(home) || !disciplinaElegivel(away)) return;
  if(Math.random() >= disciplinaProbIncidente(home, away, ctx)) return;
  // 80% dos incidentes são da claque da casa; 20% da claque visitante (o clube visitante responde).
  const culpado = Math.random() < 0.8 ? home : away;
  const dCulpado = disciplinaEnsure(culpado);
  const humor = (typeof ensureAdeptos === "function" && ensureAdeptos(culpado)) ? ensureAdeptos(culpado).humor : 55;
  const rg = Math.random() + (humor < 30 ? 0.12 : 0);
  let gravidade = rg < 0.70 ? 1 : rg < 0.94 ? 2 : 3;
  const danosViatura = culpado === home && Math.random() < 0.08;     // Art. 60.º: viatura da equipa de arbitragem
  const reincidencia = dCulpado.incidentesEpoca || 0;
  if(reincidencia >= 2 && gravidade < 2) gravidade = 2;
  const descricao = danosViatura ? "Danos na viatura da equipa de arbitragem no parque do recinto (Art. 60.º do RGHP)"
    : DISC_INCIDENTES[gravidade - 1][Math.floor(Math.random() * 3)];
  const smn = disciplinaSMN(culpado);
  let multa = Math.round(smn * DISC_MULTAS_SMN[gravidade - 1] * (1 + 0.25 * reincidencia));
  let danos = 0;
  if(danosViatura){ gravidade = 1; danos = 300 + Math.round(Math.random() * 1200); multa = Math.round(smn); }
  const portaFechada = !danosViatura && (gravidade === 3 || reincidencia >= 2) ? 1 : 0;
  dCulpado.incidentesEpoca = reincidencia + 1;
  const outro = culpado === home ? away : home;
  const caso = disciplinaNovoCaso(culpado, {
    tipo: "clube", gravidade, descricao, jogo: `${home.name} ${ctx.score.home}-${ctx.score.away} ${away.name}`,
    multa, danos, portaFechada, decisaoData: disciplinaIso(disciplinaSomaDias(null, DISC_DIAS_DECISAO_CLUBE)),
    taxaRecurso: Math.round(smn * DISC_TAXA_RECURSO_SMN.clube),
  });
  const adv = typeof ensureAdeptos === "function" ? ensureAdeptos(culpado) : null;
  if(adv) adv.humor = clamp(adv.humor - (gravidade >= 3 ? 2 : 0.8), 0, 100);
  disciplinaNoticia(culpado, `Processo disciplinar: incidentes no jogo com o ${outro.name}`,
    `O delegado e a equipa de arbitragem reportaram ao Conselho de Disciplina incidentes ligados aos adeptos do ${escapeHtml(culpado.name)} no jogo ${escapeHtml(caso.jogo)}: <b>${escapeHtml(descricao)}</b>. Como promotor do espetáculo, o clube é responsável pela segurança do recinto (Art. 59.º do RGHP). O processo foi instaurado e a decisão deve chegar a ${disciplinaFmt(caso.decisaoData)}.`);
  if(disciplinaEhUtilizador(outro) && culpado !== outro){
    // incidente da claque do adversário: sem notícia disciplinar para o utilizador (não é parte do processo)
  }
}

function disciplinaAposJogo(ctx){
  if(ctx.isFriendly) return;
  const home = state.teams[ctx.homeId], away = state.teams[ctx.awayId];
  if(!home || !away) return;
  // 1) Expulsões diretas → processo disciplinar do jogador
  (ctx.vermelhosDiretos || []).forEach(v => {
    const team = state.teams[v.side === "home" ? ctx.homeId : ctx.awayId];
    if(!disciplinaElegivel(team)) return;
    const p = (team.players || []).find(x => x.id === v.playerId);
    if(!p) return;
    const opp = v.side === "home" ? away : home;
    const caso = disciplinaNovoCaso(team, {
      tipo: "jogador", jogadorId: p.id, jogadorNome: p.name, descricao: "Expulsão direta (relatório dos árbitros)",
      jogo: `${home.name} ${ctx.score.home}-${ctx.score.away} ${away.name}`, jogosExtra: disciplinaJogosExtra(p), jogosAplicados: 0,
      decisaoData: disciplinaIso(disciplinaSomaDias(null, DISC_DIAS_DECISAO_JOGADOR)), taxaRecurso: Math.round(disciplinaSMN(team) * DISC_TAXA_RECURSO_SMN.jogador),
    });
    disciplinaNoticia(team, `Processo disciplinar: ${p.name}`,
      `Os árbitros relataram a expulsão direta de ${escapeHtml(p.name)} no jogo com o ${escapeHtml(opp.name)}. O jogador cumpre desde já 1 jogo de suspensão e o Conselho de Disciplina decide a ${disciplinaFmt(caso.decisaoData)} se o castigo é agravado.`);
  });
  // 2) Incidentes com o público (só jogos com recinto da casa)
  disciplinaIncidentePublico(ctx, home, away);
  // 3) Um jogo à porta fechada cumprido pela equipa da casa
  const dHome = home.disciplina;
  if(dHome && (dHome.portaFechada || 0) > 0 && ctx.attendance === 0 && !ctx.neutralVenue){
    dHome.portaFechada -= 1;
    disciplinaNoticia(home, "Jogo à porta fechada cumprido", `O ${escapeHtml(home.name)} cumpriu um jogo à porta fechada. ${dHome.portaFechada > 0 ? `Faltam ${dHome.portaFechada}.` : "A sanção está cumprida."}`);
  }
}

// ---------------------------------------------------------------------------------------------
// Decisão e recurso
// ---------------------------------------------------------------------------------------------
function disciplinaDecidir(team, caso){
  const hoje = state.currentDate;
  if(caso.tipo === "jogador"){
    const p = (team.players || []).find(x => x.id === caso.jogadorId);
    const extra = caso.jogosExtra || 0;
    caso.estado = "decidido";
    if(p && extra > 0){ p.suspensoJogos = (p.suspensoJogos || 0) + extra; caso.jogosAplicados = extra; }
    caso.decisao = extra > 0 ? `Castigo agravado: +${extra} jogo${extra > 1 ? "s" : ""} de suspensão (total ${extra + 1})` : "Processo arquivado: só o jogo de suspensão automática";
    caso.prazoRecurso = extra > 0 ? disciplinaIso(disciplinaSomaDias(hoje, DISC_DIAS_PRAZO_RECURSO)) : null;
    disciplinaNoticia(team, `Decisão do Conselho de Disciplina: ${caso.jogadorNome}`,
      `${extra > 0 ? `O Conselho de Disciplina decidiu agravar o castigo de ${escapeHtml(caso.jogadorNome)}: <b>+${extra} jogo${extra > 1 ? "s" : ""} de suspensão</b>. Pode recorrer até ${disciplinaFmt(caso.prazoRecurso)}, mediante o pagamento da taxa de ${fmtMoney(caso.taxaRecurso)}, com resultado incerto.` : `O Conselho de Disciplina arquivou o processo de ${escapeHtml(caso.jogadorNome)}: cumpre apenas o jogo de suspensão automática.`}`);
  } else {
    caso.estado = "decidido";
    const f = team.financeiro;
    addFinanceMovement(team, "despesa", "Multa disciplinar", `Multa do Conselho de Disciplina — ${caso.descricao}`, caso.multa, hoje);
    if(caso.danos > 0) addFinanceMovement(team, "despesa", "Multa disciplinar", "Reparação dos danos na viatura da equipa de arbitragem", caso.danos, hoje);
    const d = disciplinaEnsure(team);
    if(caso.portaFechada) d.portaFechada = (d.portaFechada || 0) + 1;
    caso.decisao = `Multa de ${fmtMoney(caso.multa)}${caso.danos ? ` + ${fmtMoney(caso.danos)} de danos` : ""}${caso.portaFechada ? " e 1 jogo à porta fechada" : ""}`;
    caso.prazoRecurso = disciplinaIso(disciplinaSomaDias(hoje, DISC_DIAS_PRAZO_RECURSO));
    disciplinaNoticia(team, "Decisão do Conselho de Disciplina: incidentes com o público",
      `O Conselho de Disciplina decidiu sobre os incidentes (${escapeHtml(caso.descricao)}): <b>${escapeHtml(caso.decisao)}</b>. Pode recorrer até ${disciplinaFmt(caso.prazoRecurso)}, mediante o pagamento da taxa de ${fmtMoney(caso.taxaRecurso)}, com resultado incerto.`);
  }
  // A IA decide logo se recorre.
  if(!disciplinaEhUtilizador(team) && disciplinaIaDeveRecorrer(team, caso)) disciplinaRecorrer(team, caso.id, true);
}
function disciplinaIaDeveRecorrer(team, caso){
  if(!caso.prazoRecurso) return false;
  const saldo = team.financeiro ? team.financeiro.saldo : 0;
  if(saldo < caso.taxaRecurso * 6) return false;
  if(caso.tipo === "jogador"){
    const p = (team.players || []).find(x => x.id === caso.jogadorId);
    if(!p) return false;
    const topo = [...team.players].sort((a, b) => overall(b) - overall(a)).slice(0, 8).some(x => x.id === p.id);
    return topo && (caso.jogosExtra || 0) >= 1;
  }
  return caso.portaFechada > 0 || caso.multa >= disciplinaSMN(team) * 4;
}
function disciplinaPodeRecorrer(team, caso){
  if(!caso || caso.estado !== "decidido" || !caso.prazoRecurso) return false;
  return new Date(disciplinaIso(state.currentDate)) <= new Date(caso.prazoRecurso) && !caso.recurso;
}
function disciplinaRecorrer(team, casoId, auto){
  const d = disciplinaEnsure(team);
  const caso = d.casos.find(c => c.id === casoId);
  if(!caso || !disciplinaPodeRecorrer(team, caso)) return { ok: false, reason: "Já não é possível recorrer." };
  const f = team.financeiro;
  if(f.saldo < caso.taxaRecurso) return { ok: false, reason: "Saldo insuficiente para pagar a taxa de recurso." };
  addFinanceMovement(team, "despesa", "Taxa de recurso", `Taxa de recurso ao Conselho de Justiça — ${caso.descricao}`, caso.taxaRecurso, state.currentDate);
  caso.recurso = { pedido: disciplinaIso(), decideEm: disciplinaIso(disciplinaSomaDias(null, DISC_DIAS_RECURSO)), resultado: null };
  caso.estado = "recurso";
  if(!auto) disciplinaNoticia(team, "Recurso submetido", `O recurso foi entregue (taxa de ${fmtMoney(caso.taxaRecurso)}). A decisão do Conselho de Justiça é conhecida a ${disciplinaFmt(caso.recurso.decideEm)}. Até lá o castigo mantém-se.`);
  return { ok: true };
}
function disciplinaResolverRecurso(team, caso){
  const r = Math.random();
  // estimativa: jogador anula 12% / reduz 30%; clube anula 10% / reduz 35%
  const pAnula = caso.tipo === "jogador" ? 0.12 : 0.10, pReduz = caso.tipo === "jogador" ? 0.30 : 0.35;
  const resultado = r < pAnula ? "anulado" : r < pAnula + pReduz ? "reduzido" : "mantido";
  caso.recurso.resultado = resultado;
  caso.estado = "final";
  let txt;
  if(caso.tipo === "jogador"){
    const p = (team.players || []).find(x => x.id === caso.jogadorId);
    const retirar = resultado === "anulado" ? (caso.jogosAplicados || 0) : resultado === "reduzido" ? 1 : 0;
    if(p && retirar > 0) p.suspensoJogos = Math.max(0, (p.suspensoJogos || 0) - retirar);
    txt = resultado === "anulado" ? `O recurso foi aceite e o agravamento do castigo de ${caso.jogadorNome} foi anulado.`
      : resultado === "reduzido" ? `O recurso foi parcialmente aceite: o castigo de ${caso.jogadorNome} desce 1 jogo.`
      : `O recurso foi recusado: o castigo de ${caso.jogadorNome} mantém-se e a taxa não é devolvida.`;
  } else {
    const d = disciplinaEnsure(team);
    if(resultado === "anulado"){
      addFinanceMovement(team, "receita", "Multa disciplinar", "Multa anulada em sede de recurso", caso.multa + (caso.danos || 0), state.currentDate);
      if(caso.portaFechada) d.portaFechada = Math.max(0, (d.portaFechada || 0) - 1);
      txt = "O recurso foi aceite: a multa e a sanção foram anuladas.";
    } else if(resultado === "reduzido"){
      addFinanceMovement(team, "receita", "Multa disciplinar", "Redução da multa em sede de recurso", Math.round(caso.multa * 0.5), state.currentDate);
      if(caso.portaFechada){ d.portaFechada = Math.max(0, (d.portaFechada || 0) - 1); addFinanceMovement(team, "despesa", "Multa disciplinar", "Jogo à porta fechada convertido em multa", Math.round(disciplinaSMN(team) * 3), state.currentDate); }
      txt = `O recurso foi parcialmente aceite: a multa desce para metade${caso.portaFechada ? " e o jogo à porta fechada é convertido em multa" : ""}.`;
    } else {
      txt = "O recurso foi recusado: a sanção mantém-se e a taxa não é devolvida.";
    }
  }
  caso.decisaoRecurso = txt;
  disciplinaNoticia(team, `Recurso: ${resultado}`, escapeHtml(txt));
}

// Diário (dailyConditionRecovery): trata todos os clubes (IA incluída).
function disciplinaDiario(){
  const hoje = disciplinaIso(state.currentDate);
  Object.values(state.teams).forEach(team => {
    const d = team.disciplina;
    if(!d || !Array.isArray(d.casos) || !d.casos.length) return;
    d.casos.forEach(caso => {
      if(caso.estado === "instaurado" && caso.decisaoData <= hoje) disciplinaDecidir(team, caso);
      else if(caso.estado === "decidido" && caso.prazoRecurso && caso.prazoRecurso < hoje) caso.estado = "final";
      else if(caso.estado === "recurso" && caso.recurso && caso.recurso.decideEm <= hoje) disciplinaResolverRecurso(team, caso);
    });
  });
}

// ---------------------------------------------------------------------------------------------
// Interface: secção "Conselho de Disciplina" no painel da Direção
// ---------------------------------------------------------------------------------------------
function disciplinaEstadoTexto(caso){
  if(caso.estado === "instaurado") return `Instaurado — decisão a ${disciplinaFmt(caso.decisaoData)}`;
  if(caso.estado === "decidido") return caso.decisao;
  if(caso.estado === "recurso") return `Em recurso — decisão a ${disciplinaFmt(caso.recurso.decideEm)}`;
  return `${caso.decisao}${caso.decisaoRecurso ? ` · ${caso.decisaoRecurso}` : ""}`;
}
function disciplinaPanelHtml(team){
  const d = disciplinaEnsure(team);
  const casos = d.casos.slice(0, 8);
  const linhas = casos.map(c => {
    const assunto = c.tipo === "jogador" ? `${escapeHtml(c.jogadorNome)} — ${escapeHtml(c.descricao)}` : escapeHtml(c.descricao);
    const pode = disciplinaPodeRecorrer(team, c);
    return `<tr><td>${disciplinaFmt(c.criado)}</td><td>${assunto}<div class="helptext">${escapeHtml(c.jogo || "")}</div></td><td>${escapeHtml(disciplinaEstadoTexto(c))}</td><td>${pode ? `<button class="btn btn-ghost disc-recorrer" data-caso="${escapeHtml(c.id)}">Recorrer (${fmtMoney(c.taxaRecurso)})</button>` : ""}</td></tr>`;
  }).join("");
  return `<div class="eyebrow" style="margin:16px 0 8px;">Conselho de Disciplina</div>
    <p class="helptext" style="margin-bottom:8px;">Expulsões diretas e incidentes com o público abrem processos. O recurso é pago e o resultado é incerto. Incidentes nesta época: ${d.incidentesEpoca || 0}${d.portaFechada ? ` · jogos à porta fechada por cumprir: ${d.portaFechada}` : ""}. Multas e taxas são estimativas em múltiplos do salário mínimo (${fmtMoney(disciplinaSMN(team))}).</p>
    <table class="stat-list"><thead><tr><th>Data</th><th>Assunto</th><th>Estado</th><th></th></tr></thead><tbody>${linhas || '<tr><td colspan="4" class="helptext">Sem processos disciplinares.</td></tr>'}</tbody></table>`;
}
document.addEventListener("click", (e) => {
  const btn = e.target.closest && e.target.closest(".disc-recorrer");
  if(!btn) return;
  const team = myTeam();
  if(!team) return;
  const r = disciplinaRecorrer(team, btn.getAttribute("data-caso"), false);
  if(!r.ok && typeof showTransientNotice === "function") showTransientNotice(r.reason);
  if(typeof renderDirectionPanel === "function") renderDirectionPanel();
});
