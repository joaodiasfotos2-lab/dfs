// Gráficos de evolução (2026-10-14, pedido do utilizador: "gráficos de evolução em Finanças e
// Carreira"). SVG em linha, sem bibliotecas. Cores validadas (OKLCH L 0.48-0.67 sobre a superfície
// escura #141B26, separação para daltonismo ΔE ≥ 10): a cor segue a entidade, nunca a ordem.
//   saldo = azul, receitas = verde-azulado, despesas = âmbar, dívida = violeta.
// Cada gráfico tem título, legenda (2+ séries), valor final por etiqueta direta, cursor com dica ao
// passar o rato e uma tabela alternativa ("Ver valores").

const GRAF_COR = { saldo: "#4A8FE7", receitas: "#1FA37C", despesas: "#C97D18", divida: "#B26DD6" };
const GRAF_MAX_MESES = 36;

function grafCompacto(v){
  if(v == null || !Number.isFinite(v)) return "—";
  const a = Math.abs(v), s = v < 0 ? "−" : "";
  if(a >= 1e6) return `${s}${(a / 1e6).toFixed(1).replace(".", ",")} M€`;
  if(a >= 1e4) return `${s}${Math.round(a / 1e3)} mil €`;
  if(a >= 1e3) return `${s}${(a / 1e3).toFixed(1).replace(".", ",")} mil €`;
  return `${s}${Math.round(a)} €`;
}
function grafInteiro(v){ return v == null || !Number.isFinite(v) ? "—" : String(Math.round(v)); }
function grafPercentagem(v){ return v == null || !Number.isFinite(v) ? "—" : `${Math.round(v)}%`; }

function grafEscala(min, max, ticks){
  if(!(max > min)){ max = min + 1; }
  const passoBruto = (max - min) / ticks, mag = Math.pow(10, Math.floor(Math.log10(passoBruto)));
  const r = passoBruto / mag, passo = (r <= 1 ? 1 : r <= 2 ? 2 : r <= 2.5 ? 2.5 : r <= 5 ? 5 : 10) * mag;
  const lo = Math.floor(min / passo) * passo, hi = Math.ceil(max / passo) * passo;
  const out = [];
  for(let v = lo; v <= hi + passo * 0.001; v += passo) out.push(Math.round(v * 1e6) / 1e6);
  return out;
}

// cfg: { titulo, nota, x:[rótulos], series:[{nome, cor, valores:[número|null]}], fmt, invertido, inteiro, notas:[texto por ponto], min, max }
let grafSeq = 0;
function grafHtml(cfg){
  const id = `graf-${++grafSeq}`;
  const W = 640, H = 230, ml = 62, mr = 22, mt = 16, mb = 30;
  const pw = W - ml - mr, ph = H - mt - mb;
  const n = cfg.x.length;
  const todos = [];
  cfg.series.forEach(s => s.valores.forEach(v => { if(v != null && Number.isFinite(v)) todos.push(v); }));
  if(!todos.length || n < 2) return `<div class="graf"><div class="graf-titulo">${escapeHtml(cfg.titulo)}</div><p class="helptext">${escapeHtml(cfg.vazio || "Ainda não há dados suficientes para este gráfico.")}</p></div>`;
  if(cfg.todosZero && todos.every(v => v === 0)) return `<div class="graf"><div class="graf-titulo">${escapeHtml(cfg.titulo)}</div><p class="helptext">${escapeHtml(cfg.todosZero)}</p></div>`;
  let lo = Math.min(...todos), hi = Math.max(...todos);
  if(cfg.min != null) lo = Math.min(lo, cfg.min);
  if(cfg.max != null) hi = Math.max(hi, cfg.max);
  const ticks = cfg.inteiro ? (() => { const a = Math.floor(lo), b = Math.ceil(hi), out = []; const passo = Math.max(1, Math.ceil((b - a) / 5)); for(let v = a; v <= b; v += passo) out.push(v); if(out[out.length - 1] < b) out.push(out[out.length - 1] + passo); return out; })() : grafEscala(lo, hi, 4);
  const t0 = ticks[0], t1 = ticks[ticks.length - 1];
  const px = i => ml + (n === 1 ? pw / 2 : pw * i / (n - 1));
  const py = v => { const f = (v - t0) / ((t1 - t0) || 1); return mt + ph * (cfg.invertido ? f : 1 - f); };
  const fmt = cfg.fmt || grafInteiro;
  let svg = `<svg viewBox="0 0 ${W} ${H}" class="graf-svg" role="img" aria-label="${escapeHtml(cfg.titulo)}" preserveAspectRatio="xMidYMid meet">`;
  ticks.forEach(t => {
    const y = py(t);
    svg += `<line x1="${ml}" x2="${W - mr}" y1="${y.toFixed(1)}" y2="${y.toFixed(1)}" class="graf-grelha${t === 0 && t0 < 0 ? " graf-zero" : ""}"/><text x="${ml - 8}" y="${(y + 4).toFixed(1)}" class="graf-eixo" text-anchor="end">${escapeHtml(fmt(t))}</text>`;
  });
  const passoX = Math.max(1, Math.ceil(n / 8));
  for(let i = 0; i < n; i += passoX){
    svg += `<text x="${px(i).toFixed(1)}" y="${H - 8}" class="graf-eixo" text-anchor="${i === 0 ? "start" : "middle"}">${escapeHtml(cfg.x[i])}</text>`;
  }
  cfg.series.forEach(s => {
    let d = "", aberto = false;
    s.valores.forEach((v, i) => {
      if(v == null || !Number.isFinite(v)){ aberto = false; return; }
      d += `${aberto ? "L" : "M"}${px(i).toFixed(1)},${py(v).toFixed(1)} `;
      aberto = true;
    });
    svg += `<path d="${d.trim()}" fill="none" stroke="${s.cor}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"${s.tracejado ? ' stroke-dasharray="6 4"' : ""}/>`;
    const ultimo = (() => { for(let i = s.valores.length - 1; i >= 0; i--) if(s.valores[i] != null && Number.isFinite(s.valores[i])) return i; return -1; })();
    s.valores.forEach((v, i) => {
      if(v == null || !Number.isFinite(v)) return;
      if(n <= 14 || i === ultimo) svg += `<circle cx="${px(i).toFixed(1)}" cy="${py(v).toFixed(1)}" r="4" fill="${s.cor}" class="graf-ponto"/>`;
    });
    if(ultimo >= 0){
      const x = px(ultimo), y = py(s.valores[ultimo]);
      svg += `<text x="${Math.min(x, W - mr).toFixed(1)}" y="${(y - 10).toFixed(1)}" class="graf-valor" text-anchor="end">${escapeHtml(fmt(s.valores[ultimo]))}</text>`;
    }
  });
  svg += `<line class="graf-cursor" x1="0" x2="0" y1="${mt}" y2="${mt + ph}" style="display:none"/>`;
  cfg.series.forEach((s, k) => { svg += `<circle class="graf-cursor-ponto" data-s="${k}" r="5" fill="${s.cor}" style="display:none"/>`; });
  svg += `<rect class="graf-alvo" x="${ml}" y="${mt}" width="${pw}" height="${ph}" fill="transparent"/></svg>`;
  const legenda = cfg.series.length >= 2
    ? `<div class="graf-legenda">${cfg.series.map(s => `<span><i style="background:${s.cor}"></i>${escapeHtml(s.nome)}</span>`).join("")}</div>` : "";
  const dados = { x: cfg.x, notas: cfg.notas || null, series: cfg.series.map(s => ({ nome: s.nome, cor: s.cor, valores: s.valores, txt: s.valores.map(v => v == null ? "—" : fmt(v)) })),
    geo: { ml, mr, mt, ph, pw, W, H, t0, t1, invertido: !!cfg.invertido } };
  const tabela = `<details class="graf-tabela"><summary>Ver valores</summary><table class="stat-list"><thead><tr><th>${escapeHtml(cfg.xRotulo || "Período")}</th>${cfg.series.map(s => `<th class="num">${escapeHtml(s.nome)}</th>`).join("")}${cfg.notas ? "<th></th>" : ""}</tr></thead><tbody>${cfg.x.map((x, i) => `<tr><td>${escapeHtml(x)}</td>${dados.series.map(s => `<td class="num">${escapeHtml(s.txt[i])}</td>`).join("")}${cfg.notas ? `<td>${escapeHtml(cfg.notas[i] || "")}</td>` : ""}</tr>`).reverse().join("")}</tbody></table></details>`;
  return `<div class="graf" id="${id}" data-graf="${escapeHtml(JSON.stringify(dados))}">
    <div class="graf-titulo">${escapeHtml(cfg.titulo)}</div>${cfg.nota ? `<div class="helptext" style="margin:0 0 4px;">${escapeHtml(cfg.nota)}</div>` : ""}${legenda}
    <div class="graf-wrap">${svg}<div class="graf-dica" style="display:none"></div></div>${tabela}</div>`;
}

// Cursor + dica: um único ligador por contentor, corrido depois de cada innerHTML.
function grafLigar(raiz){
  raiz.querySelectorAll(".graf[data-graf]").forEach(el => {
    if(el.__grafLigado) return;
    el.__grafLigado = true;
    let dados;
    try { dados = JSON.parse(el.getAttribute("data-graf")); } catch(e){ return; }
    const svg = el.querySelector("svg"), alvo = el.querySelector(".graf-alvo"), cur = el.querySelector(".graf-cursor"), dica = el.querySelector(".graf-dica"), wrap = el.querySelector(".graf-wrap");
    if(!svg || !alvo) return;
    const g = dados.geo, n = dados.x.length;
    const py = v => { const f = (v - g.t0) / ((g.t1 - g.t0) || 1); return g.mt + g.ph * (g.invertido ? f : 1 - f); };
    const esconder = () => { cur.style.display = "none"; dica.style.display = "none"; el.querySelectorAll(".graf-cursor-ponto").forEach(c => c.style.display = "none"); };
    const mover = ev => {
      const r = svg.getBoundingClientRect();
      if(!r.width) return;
      const xv = (ev.clientX - r.left) / r.width * g.W;
      let i = Math.round((xv - g.ml) / (g.pw / (n - 1)));
      i = Math.max(0, Math.min(n - 1, i));
      const x = g.ml + g.pw * i / (n - 1);
      cur.setAttribute("x1", x); cur.setAttribute("x2", x); cur.style.display = "";
      el.querySelectorAll(".graf-cursor-ponto").forEach(c => {
        const s = dados.series[+c.getAttribute("data-s")], v = s.valores[i];
        if(v == null){ c.style.display = "none"; return; }
        c.setAttribute("cx", x); c.setAttribute("cy", py(v)); c.style.display = "";
      });
      dica.innerHTML = `<b>${escapeHtml(dados.x[i])}</b>${dados.series.map(s => `<div><i style="background:${s.cor}"></i>${escapeHtml(s.nome)}: <b>${escapeHtml(s.txt[i])}</b></div>`).join("")}${dados.notas && dados.notas[i] ? `<div class="graf-nota">${escapeHtml(dados.notas[i])}</div>` : ""}`;
      dica.style.display = "";
      const wr = wrap.getBoundingClientRect(), xpx = x / g.W * r.width;
      const larg = dica.offsetWidth;
      dica.style.left = `${Math.max(0, Math.min(wr.width - larg, xpx + 12 + (xpx + larg + 24 > wr.width ? -larg - 24 : 0)))}px`;
      dica.style.top = "8px";
    };
    alvo.addEventListener("pointermove", mover);
    alvo.addEventListener("pointerdown", mover);
    alvo.addEventListener("pointerleave", esconder);
  });
}

// ---------- dados: finanças ----------
function grafFinSerieRegistar(team, monthKey){
  const f = team.financeiro;
  if(!Array.isArray(f.serieMensal)) f.serieMensal = [];
  const rec = f.receitasEpoca || 0, des = f.despesasEpoca || 0;
  const ur = Number.isFinite(f.__serieUltRec) ? f.__serieUltRec : 0, ud = Number.isFinite(f.__serieUltDes) ? f.__serieUltDes : 0;
  const dr = rec >= ur ? rec - ur : rec, dd = des >= ud ? des - ud : des;   // a época nova repõe os acumulados a 0
  f.__serieUltRec = rec; f.__serieUltDes = des;
  const reg = { ym: monthKey, saldo: Math.round(f.saldo || 0), divida: Math.round((f.divida || 0) + (f.creditoUtilizado || 0)), rec: Math.round(dr), des: Math.round(dd) };
  const i = f.serieMensal.findIndex(x => x.ym === monthKey);
  if(i >= 0) f.serieMensal[i] = reg; else f.serieMensal.push(reg);
  if(f.serieMensal.length > GRAF_MAX_MESES) f.serieMensal = f.serieMensal.slice(-GRAF_MAX_MESES);
}
const GRAF_MESES_CURTOS = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
function grafRotuloMes(ym){
  const [a, m] = String(ym).split("-");
  return `${GRAF_MESES_CURTOS[(+m || 1) - 1]} ${String(a).slice(2)}`;
}
function grafFinancasHtml(team){
  const f = team.financeiro || {};
  const serie = (f.serieMensal || []).slice();
  // ponto "agora" (saldo actual) só se ainda não houver registo deste mês
  const x = serie.map(r => grafRotuloMes(r.ym));
  const epocas = (f.historicoEpocas || []).slice(-12);
  return `<div class="graf-grelha-cartoes">
    ${grafHtml({ titulo: "Saldo disponível", nota: "Registado no início de cada mês.", x, fmt: grafCompacto, vazio: "O gráfico aparece a partir do segundo mês de jogo.", xRotulo: "Mês",
      series: [{ nome: "Saldo", cor: GRAF_COR.saldo, valores: serie.map(r => r.saldo) }] })}
    ${grafHtml({ titulo: "Receitas e despesas por mês", nota: "Tudo o que entrou e saiu entre dois registos mensais, incluindo bilheteira e prémios.", x, fmt: grafCompacto, min: 0, vazio: "O gráfico aparece a partir do segundo mês de jogo.", xRotulo: "Mês",
      series: [{ nome: "Receitas", cor: GRAF_COR.receitas, valores: serie.map(r => r.rec) }, { nome: "Despesas", cor: GRAF_COR.despesas, valores: serie.map(r => r.des) }] })}
    ${grafHtml({ titulo: "Dívida total", x, fmt: grafCompacto, min: 0, todosZero: "Sem dívida nem crédito utilizado neste período.", vazio: "O gráfico aparece a partir do segundo mês de jogo.", xRotulo: "Mês",
      series: [{ nome: "Dívida", cor: GRAF_COR.divida, valores: serie.map(r => r.divida) }] })}
    ${grafHtml({ titulo: "Saldo e dívida no fim de cada época", x: epocas.map(e => e.epoca), fmt: grafCompacto, vazio: "O gráfico aparece no fecho da segunda época.", xRotulo: "Época",
      series: [{ nome: "Saldo final", cor: GRAF_COR.saldo, valores: epocas.map(e => e.saldoFinal) }, { nome: "Dívida final", cor: GRAF_COR.divida, valores: epocas.map(e => e.dividaFinal) }] })}
  </div>`;
}
function grafRenderFinancas(team){
  const box = document.getElementById("financeCharts");
  if(!box || !team) return;
  box.innerHTML = grafFinancasHtml(team);
  grafLigar(box);
}

// ---------- dados: carreira ----------
function grafCarreiraSerie(){
  const g = ensureManagerCareer();
  const team = state.teams[state.userTeamId];
  const reps = (g.serieReputacao || []).slice();
  const aval = ((team && team.avaliacaoDirecao) || []).slice().sort((a, b) => (seasonNumberFromEpocaLabel(a.epoca) || 0) - (seasonNumberFromEpocaLabel(b.epoca) || 0));
  // posições de todos os mandatos (os já terminados + o actual)
  const mandatos = (g.historico || []).slice();
  const desde = Number.isFinite(g.epocaInicioClube) ? g.epocaInicioClube : state.season;
  if(team) mandatos.push({ clubName: team.name, temporadas: seasonsAtClubForTenure(team, desde) });
  const posicoes = [];
  mandatos.forEach(m => (m.temporadas || []).forEach(t => { if(Number.isFinite(t.posicaoFinal)) posicoes.push({ epoca: t.epoca, pos: t.posicaoFinal, clube: m.clubName, campeao: !!t.campeao, descida: !!t.descida }); }));
  posicoes.sort((a, b) => (seasonNumberFromEpocaLabel(a.epoca) || 0) - (seasonNumberFromEpocaLabel(b.epoca) || 0));
  return { reps, aval, posicoes };
}
function grafCarreiraHtml(){
  const { reps, aval, posicoes } = grafCarreiraSerie();
  const g = ensureManagerCareer();
  const repX = reps.map(r => r.epoca), repV = reps.map(r => r.rep);
  repX.push("Agora"); repV.push(g.reputacao);
  return `<div class="graf-grelha-cartoes">
    ${grafHtml({ titulo: "Reputação pessoal", nota: "Escala 0-99, actualizada no fim de cada época.", x: repX, fmt: grafInteiro, min: 0, max: 99, inteiro: false, xRotulo: "Época",
      vazio: "O gráfico aparece no fim da primeira época.",
      series: [{ nome: "Reputação", cor: GRAF_COR.saldo, valores: repV }] })}
    ${grafHtml({ titulo: "Posição final na liga", nota: "O 1.º lugar fica no topo; muda de clube e de divisão ao longo da carreira.", x: posicoes.map(p => p.epoca), fmt: grafInteiro, invertido: true, inteiro: true, xRotulo: "Época",
      vazio: "O gráfico aparece no fim da primeira época.",
      notas: posicoes.map(p => `${p.clube}${p.campeao ? " · Campeão" : ""}${p.descida ? " · Descida" : ""}`),
      series: [{ nome: "Posição final", cor: GRAF_COR.divida, valores: posicoes.map(p => p.pos) }] })}
    ${grafHtml({ titulo: "Objetivos da direção cumpridos", nota: "No clube actual: peso dos objetivos cumpridos em cada época.", x: aval.map(a => a.epoca), fmt: grafPercentagem, min: 0, max: 100, xRotulo: "Época",
      vazio: "O gráfico aparece no fim da primeira época.",
      series: [{ nome: "Cumprimento", cor: GRAF_COR.receitas, valores: aval.map(a => Math.round(presTaxaAvaliacao(a) * 100)) }] })}
  </div>`;
}
function grafRenderCarreira(){
  const box = document.getElementById("careerCharts");
  if(!box) return;
  box.innerHTML = `<div class="eyebrow" style="margin:6px 0 8px;">Evolução</div>${grafCarreiraHtml()}`;
  grafLigar(box);
}
